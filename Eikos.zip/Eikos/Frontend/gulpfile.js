'use strict';
var gulp = require('gulp');
var runSequence = require('run-sequence');
var del = require('del');
var fs = require('fs');
var jshint = require('gulp-jshint');
var stylish = require('jshint-stylish');
var bowerRequireJS = require('bower-requirejs');
var rjs = require('requirejs');
var pkg = require('./package.json');
var rename = require('gulp-rename');
var uglify = require('gulp-uglify');
var replace = require('gulp-replace');
var serve = require('gulp-serve');
var karma = require('karma').server;
var colors = require('colors');

//name used for versioned files
var vname = pkg.name + '-' + pkg.version;

gulp.task('default', function() {
    // place code for your default task here
});

//clean build, dist, and public folders
gulp.task('clean', function(cb) {
    del( ['build/**/*', 'dist/**/*', 'public/**/*'], cb);
});

var lintrc = JSON.parse(fs.readFileSync('./.jslintrc', 'utf8'));
//lint the code
gulp.task('jshint', function() {
  return gulp.src(['*.js', 'src/**/*.js', 'test/**/*.js', '!test/examples/**/*.js'])
    .pipe(jshint(lintrc))
    .pipe(jshint.reporter(stylish))
    .pipe(jshint.reporter('fail'));
});

//update the rjsconfig with all dependencies from bower_components
gulp.task('bower-rjs', function(callback) {
    var options = {
        baseUrl: 'src',
        config: 'rjsconfig.js',
        transitive: true
    };

    bowerRequireJS(options, function (rjsConfigFromBower) {
        callback();
    });
});

//compile all js files with r.js into a single js blob
gulp.task('rjs', function(cb) {
    rjs.optimize({
            name: 'app/app',
            optimize: 'none',
            baseUrl: 'src',
            mainConfigFile: 'rjsconfig.js',
            include: ['../rjsconfig','almond'],
            out: 'build/' + vname + '.js'
    }, function() { cb(); });
});

//minify the js blob (source map not working yet)
gulp.task('uglify', function() {
    return gulp.src('build/' + vname + '.js')
        .pipe(uglify({
            outSourceMap: vname + '.min.js.map',
            sourceRoot: '/src/',
         }))
        .pipe(rename({ extname: '.min.js'}))
        .pipe(gulp.dest('build/'));
});

gulp.task('build', function(cb) {
    runSequence('clean', 'jshint', 'bower-rjs', 'rjs', 'uglify', cb);
});

//copy resources to dist folder for serving like production
gulp.task('copyjs', function() {
    return gulp.src('build/*')
        .pipe(gulp.dest('dist/app/js/'));
});

gulp.task('copyroot', function() {
    return gulp.src(['app.json', 'src/*.html'])
        .pipe(gulp.dest('dist/app/'));
});

gulp.task('copyimg', function() {
    return gulp.src('src/img/*')
        .pipe(gulp.dest('dist/public/img/'));
});

gulp.task('copyimg_logo', function() {
    return gulp.src('src/img/logo.png')
        .pipe(gulp.dest('dist/app/img/'));
});


gulp.task('copyconfig', function() {
    return gulp.src('src/config/**/*')
        .pipe(gulp.dest('dist/app/config/'));
});

gulp.task('copystatus', function () {
    return gulp.src('src/status/**/*')
        .pipe(gulp.dest('dist/app/status/'));
});

gulp.task('copypublic', function () {
    return gulp.src(['src/public/**/*', 'src/img/favicon.ico', 'app.json'])
        .pipe(gulp.dest('dist/public/'));
});

gulp.task('copy', function(cb) {
    runSequence('copyjs', 'copyroot', 'copyconfig', 'copystatus', 'copypublic', 'copyimg', 'copyimg_logo', cb);
});

//modify the dist/index.html to point to minified blob
gulp.task('replace', function(){
  return gulp.src('dist/app/index.html')
    .pipe(replace(/^.*require.js.*$\n/gm, ''))
    .pipe(replace(/^.*rjsconfig.js.*$\n/gm, ''))
    .pipe(replace(/["']app\/app\.js["']/gm, '"js/' + vname + '.min.js"'))
    .pipe(gulp.dest('dist/app'));
});

gulp.task('release', function(cb) {
    runSequence('build', 'copy', 'replace', cb)
});

gulp.task('serve', serve({
    root: ['dist/app'],
    port: 9000
}));

gulp.task('debug', serve({
    root: ['src', '.'],
    port: 9000,
    middleware: function(req, res, next) {
        // console.log(req);
        console.log('[' + new Date().toLocaleString().blue + ']: ' +
                    '(' + req.connection.remoteAddress.underline.red + ':' + req.headers['user-agent'].green + ')' + '\n' +
                    String(req.method + ' ' + req.url + ' ' + 'HTTP/' + req.httpVersion).underline.yellow);
        next();
    }
}));

gulp.task('karmateamcity', function(cb) {
    karma.start({
        configFile: __dirname + '/mykarma.conf.js',
        singleRun: true,
        logLevel: 'debug',
        reporters: 'teamcity'
    }, cb);
});

gulp.task('karma', function(cb) {
    karma.start({
        configFile: __dirname + '/mykarma.conf.js',
        singleRun: true,
        logLevel: 'debug',
    }, cb);
});
