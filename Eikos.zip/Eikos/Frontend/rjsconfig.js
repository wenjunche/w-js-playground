/*jshint ignore:start*/
requirejs({
  baseUrl: 'src',
  config: {
    'scalejs.statechart-scion': {
      logStatesEnteredAndExited: true
    }
  },
  scalejs: {
    extensions: [
      'backend',
      'formattedNumber',
      'scalejs.mvvm',
      'scalejs.statechart-scion',
      'scalejs.reactive',
      'scalejs.routing-historyjs',
      'scalejs.visualization',
      'toolkit',
      'knockout.hammer',
      'openfin.windowFactory'
    ]
  },
  map: {
    '*': {
      sandbox: 'scalejs.sandbox',
      bindings: 'scalejs.mvvm.bindings',
      views: 'scalejs.mvvm.views',
      styles: 'scalejs.styles-less',
      less: '../bower_components/less/dist/less-1.5.0'
    }
  },
  paths: {
    almond: '../bower_components/almond/almond',
    backend: 'extensions/backend',
    requirejs: '../bower_components/requirejs/require',
    scalejs: '../bower_components/scalejs/dist/scalejs.min',
    linqjs: '../bower_components/linqjs/linq',
    'scalejs.mvvm': '../bower_components/scalejs.mvvm/dist/scalejs.mvvm',
    'scalejs.mvvm.views': '../bower_components/scalejs.mvvm/dist/scalejs.mvvm',
    'scalejs.mvvm.bindings': '../bower_components/scalejs.mvvm/dist/scalejs.mvvm',
    knockout: '../bower_components/knockout/dist/knockout',
    'knockout.mapping': '../bower_components/knockout.mapping/knockout.mapping',
    'scalejs.functional': '../bower_components/scalejs.functional/dist/scalejs.functional.min',
    'scalejs.styles-less': '../bower_components/scalejs.styles-less/scalejs.styles',
    formattedNumber: 'extensions/formattedNumber',
    underscore: '../bower_components/underscore/underscore',
    less: '../bower_components/less/dist/less-1.5.0',
    text: '../bower_components/text/text',
    toolkit: 'extensions/toolkit',
    'scalejs.statechart-scion': '../bower_components/scalejs.statechart-scion/dist/scalejs.statechart-scion.min',
    'scalejs.reactive': '../bower_components/scalejs.reactive/dist/scalejs.reactive.min',
    'scalejs.routing-historyjs': '../bower_components/scalejs.routing-historyjs/dist/scalejs.routing-historyjs.min',
    'scalejs.linq-linqjs': '../bower_components/scalejs.linq-linqjs/dist/scalejs.linq-linqjs.min',
    'scion-ng': '../bower_components/scion-ng/lib/scion',
    'rx.all': '../bower_components/rxjs/dist/rx.all.min',
    'rx.all.compat': '../bower_components/rxjs/dist/rx.all.compat.min',
    rx: '../bower_components/rxjs/dist/rx.min',
    'rx.compat': '../bower_components/rxjs/dist/rx.compat.min',
    'rx.aggregates': '../bower_components/rxjs/dist/rx.aggregates.min',
    'rx.async': '../bower_components/rxjs/dist/rx.async.min',
    'rx.async.compat': '../bower_components/rxjs/dist/rx.async.compat.min',
    'rx.backpressure': '../bower_components/rxjs/dist/rx.backpressure.min',
    'rx.binding': '../bower_components/rxjs/dist/rx.binding.min',
    'rx.coincidence': '../bower_components/rxjs/dist/rx.coincidence.min',
    'rx.experimental': '../bower_components/rxjs/dist/rx.experimental.min',
    'rx.lite': '../bower_components/rxjs/dist/rx.lite.min',
    'rx.lite.compat': '../bower_components/rxjs/dist/rx.lite.compat.min',
    'rx.joinpatterns': '../bower_components/rxjs/dist/rx.joinpatterns.min',
    'rx.testing': '../bower_components/rxjs/dist/rx.testing.min',
    'rx.time': '../bower_components/rxjs/dist/rx.time.min',
    'rx.virtualtime': '../bower_components/rxjs/dist/rx.virtualtime.min',
    'less-builder': '../bower_components/scalejs.styles-less/less-builder',
    normalize: '../bower_components/scalejs.styles-less/normalize',
    history: '../bower_components/history/scripts/bundled-uncompressed/html5/native.history',
    '_scalejs.routing-historyjs': '../bower_components/_scalejs.routing-historyjs/dist/scalejs.routing-historyjs.min',
    hammer: '../bower_components/hammer.js/hammer',
    'knockout.hammer': 'extensions/knockout.hammer',
    'openfin.windowFactory': 'extensions/openfin.windowFactory',
    d3: '../bower_components/d3/d3',
    'scalejs.visualization': '../bower_components/scalejs.visualization/dist/scalejs.visualization',
    'scalejs.canvas': '../bower_components/scalejs.canvas/dist/scalejs.canvas',
    chai: '../bower_components/chai/chai',
    mocha: '../bower_components/mocha/mocha'
  },
  shim: {
    history: {
      exports: 'History'
    },
    'scalejs.mvvm': {
      deps: [
        'knockout.mapping',
        'scalejs.functional'
      ]
    }
  },
  packages: [

  ]
});
/*jshint ignore:end*/
