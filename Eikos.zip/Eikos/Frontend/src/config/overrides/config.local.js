window.service = 'http://localhost:9002';
window.baseUrl = 'http://localhost:9002/src';
