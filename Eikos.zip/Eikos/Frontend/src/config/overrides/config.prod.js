window.service = '';
window.baseUrl = 'https://mobile.eikospartners.com/app';
