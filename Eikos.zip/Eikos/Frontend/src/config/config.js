window.service = 'https://mobile.eikospartners.com'; //'http://localhost:9002';
window.baseUrl = 'http://localhost:9000';
