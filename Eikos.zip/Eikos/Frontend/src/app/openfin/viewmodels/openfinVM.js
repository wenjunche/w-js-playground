/*global define */
/*global _:false */

define([
    'scalejs.sandbox!main',
    'underscore'
], function (
    sandbox,
    _
) {
    'use strict';
    /*jshint camelcase: false */
    return function () {
        var observable = sandbox.mvvm.observable,
            computed = sandbox.mvvm.computed,
            raise = sandbox.state.raise;

        var showAllWindows = function (exclude) {
            /* global fin */
            var application = fin.desktop.Application.getCurrent();

            application.getChildWindows(function (children) {
                //filter out child windows in exclude list
                children = _.filter(children, function(c) { return ! _.contains(exclude, c) });
                children.forEach(function (childWindow) {

                    childWindow.updateOptions({
                        opacity: 0
                    });

                    childWindow.show();

                    childWindow.animate({
                        opacity:  {
                            opacity: 1,
                            duration: 1000
                    }});

                });
            });
        };

        var hideAllWindows = function hideAllWindows() {
            var application = fin.desktop.Application.getCurrent();

            application.getChildWindows(function (children) {
                children.forEach(function (childWindow) {
                    childWindow.isShowing(function(showing) {
                        if ( showing ) {
                            childWindow.updateOptions({opacity: 1});

                            childWindow.hide();


                            childWindow.animate({
                                opacity:  {
                                    opacity: 0,
                                    duration: 1000
                            }}, function() { console.log('Done'); childWindow.hide();});
                        }

                    });
                });
            });
        };

        var tileWindows = function (exclude) {
            /* global fin */
            var application = fin.desktop.Application.getCurrent();

            var children = sandbox.windowFactory.getChildren();
            //application.getChildWindows(function (children) {
            //pull out the first item whici is the control panel window
            var controlPanelWindow = children.shift();

            //filter out child windows in exclude list
            children = _.filter(children, function(c) {
                return ! _.some(exclude, function(e) {
                    return e.name === c.name
                })
            });

            //filter out child windows that are hidden
            children = _.filter(children, function(c) { return ! c._hidden; });

            //add the main window
            children.push(controlPanelWindow);
            var observables = [];
            children.forEach(function(w) {
                observables.push(sandbox.reactive.Observable.create(function(observer) {
                    w.getBounds(function(bounds) {
                        w.w = bounds.width;
                        w.h = bounds.height;
                        observer.onCompleted();
                    });
                }));
            });
            sandbox.reactive.Observable.merge(observables).subscribe(_.noop, _.noop, function() {

                var monitorRect = sandbox.windowFactory.monitorInfo.primaryMonitor.availableRect;
                var screenWidth = monitorRect.right - monitorRect.left;
                var screenHeight = monitorRect.bottom - monitorRect.top;
                var startTop = 0;
                var startLeft = 0;

                //find control panel window
                controlPanelWindow = children.pop();
                //calculate size of screen minus control panel --
                //  take away height if control panel is wider than tall otherwise take away width
                if (controlPanelWindow.w > controlPanelWindow.h) {
                    screenHeight -= controlPanelWindow.h;
                    startTop = controlPanelWindow.h;
                } else {
                    screenWidth -= controlPanelWindow.w;
                    startLeft = controlPanelWindow.w;
                }
                controlPanelWindow.t = 0;
                controlPanelWindow.l = 0;
                //count windows aside from control panel
                var wins = children.length;
                //calculate rows and columns of tilesd windows based on count
                var cols = Math.ceil(Math.sqrt(wins));
                var rows = Math.ceil(wins / cols);
                console.log('calculated for tiling: rows: ' + rows + '; cols: ' + cols);
                var windowWidth = Math.floor(screenWidth / cols);
                var windowHeight = Math.floor(screenHeight / rows);
                console.log('screenWidth: ' + screenWidth + '; screenHeight: ' + screenHeight);
                console.log('windowWidth: ' + windowWidth + '; windowHeight: ' + windowHeight);
                //calculate top, left for each window
                for (var i = 0; i < wins; i += 1) {
                    var row = Math.floor(i / cols);
                    var col = i % cols;
                    children[i].w = windowWidth;
                    children[i].h = windowHeight;
                    children[i].t = startTop + (windowHeight * row);
                    children[i].l = startLeft + (windowWidth * col);
                }

                //add back the main window
                children.push(controlPanelWindow);

                //run rearrange call
                children.forEach(function (childWindow) {

                    childWindow.updateOptions({
                        opacity: 0
                    });

                    childWindow.show();

                    childWindow.animate({
                        opacity:  {
                            opacity: 1,
                            duration: 75
                        },
                        size: {
                            width: childWindow.w,
                            height: childWindow.h,
                            duration: 150
                        },
                        position: {
                            left: childWindow.l,
                            top: childWindow.t,
                            duration: 150
                        }
                    });

                });
            });
        };

        return {
            showAllWindows: showAllWindows,
            hideAllWindows: hideAllWindows,
            tileWindows: tileWindows
        };
    };
});
