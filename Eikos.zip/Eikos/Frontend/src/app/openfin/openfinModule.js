/*global define */
/*global fin */
define([
    'scalejs.sandbox!main',
    'app/openfin/viewmodels/openfinVM',
    'knockout',
    'bindings!openfin',
    'views!openfin',
    'styles!../main/styles/main'
], function (
    sandbox,
    openfinVM,
    ko
) {
    'use strict';
    /*jshint camelcase: false */

    return function openfin() {
        var // imports
            root = sandbox.mvvm.root,
            template = sandbox.mvvm.template,
            registerStates = sandbox.state.registerStates,
            routerState = sandbox.routing.routerState,
            route = sandbox.routing.route,
            gotoInternally = sandbox.state.builder.gotoInternally,
            on = sandbox.state.builder.on,
            raise = sandbox.state.raise,
            state = sandbox.state.builder.state,
            parallel = sandbox.state.builder.parallel,
            onEntry = sandbox.state.builder.onEntry,
            // vars
            vm = openfinVM(sandbox),
            isOpenFin = typeof(fin) !== 'undefined',
            horizCPHeight = 106;

        var setupDocking = function(mainWindow) {
              mainWindow.vertSnap = horizCPHeight;
              mainWindow.addEventListener('snap-to-edge', function(e) {
                  var monitorRect = sandbox.windowFactory.monitorInfo.primaryMonitor.availableRect;
                  if (mainWindow.isDocked()) {
                      return;
                  }
                  if (e.y <= horizCPHeight || e.y >= monitorRect.bottom - horizCPHeight) {
                      raise('openfin.evt.hdock');
                  }

              });
              mainWindow.addEventListener('unsnap-from-edge', function(e) {
                  mainWindow.movedSinceDragStart = true;
                  raise('openfin.evt.undock');

              });
        };

        var focusShowBringToFront = function(win) {
            win.show();
            win.bringToFront();
            win.focus();
        };

        var setupSystemTray = function(main, mainWindow) {
            var menuWndw = sandbox.windowFactory.createWindow({
                name: 'SystemTrayMenu',
                url: window.baseUrl + '/details.html',
                defaultWidth: 120,
                defaultHeight: 120,
                cornerRounding: { width: 0, height: 0 },
                fitToElement: '#context-menu-container',
                onRenderable: function(body) {
                    var window = menuWndw.getNativeWindow();
                    window.document.documentElement.classList.remove('openfin');
                    var opening_comment = window.document.createComment(' ko render: $data'),
                    closing_comment = window.document.createComment(' /ko ');
                    body.appendChild(opening_comment);
                    body.appendChild(closing_comment);

                    ko.applyBindings(template('systray_menu_template', main), body);
                    menuWndw._addEventListener('blurred', function() {
                        menuWndw.hide();
                    });
                }
            });
            main.menuWndw = menuWndw;
            fin.desktop.Application.getCurrent().setTrayIcon(
                window.baseUrl + '/img/logo.png',
                function (evt) {
                    if (evt.button === 0) {
                        raise('openfin.evt.popup');
                    } else if (evt.button === 2) {
                        fin.desktop.System.getMousePosition(function (evt) {
                            var x = parseInt(evt.left),
                                y = parseInt(evt.top);
                            var contentWndw = main.menuWndw.contentWindow;
                             
                            main.menuWndw.moveTo(x, y - contentWndw.outerHeight);
                            main.menuWndw.updateOptions({alwaysOnTop: true});
                            main.menuWndw.show();
                            main.menuWndw.focus();

                        });
                        console.log('right click');
                    }
                    console.log(arguments);
                }
            );
        };

        var horizDock = function(win) {
            win.contentWindow.document.getElementById('main').classList.add('horizcp');
            win.resizeTo(746, horizCPHeight, 'top-left');
        };

        // Register application state for the module.
        if (isOpenFin) {

            registerStates('app',
                  state('openfin',
                      onEntry(function () {
                          var main = this.main;
                          //setup main window
                          var mainWindow = fin.desktop.Window.getCurrent();
                          sandbox.windowFactory.registerWindow(mainWindow);
                          main.mainWindow = mainWindow;
                          main.wndw = mainWindow;
                          main.openfinVM = vm;
                          root(template('openfin_main_template', main));
                          mainWindow.contentWindow.document.documentElement.classList.add('openfin');
                          mainWindow.contentWindow.document.body.classList.add('openfin');
                          mainWindow.defineDraggableElements(mainWindow.defaultDraggableElements());

                          setupDocking(mainWindow);

                          setupSystemTray(main, mainWindow);
                      }),
                      state('openfin.undocked',
                          onEntry(function() {
                              var mainWindow = this.main.mainWindow;
                              mainWindow.resizeTo(300, 650, 'top-left');
                              mainWindow.contentWindow.document.getElementById('main').classList.remove('horizcp');
                              mainWindow.restore(function() { focusShowBringToFront(mainWindow) });
                          }),
                          on('openfin.evt.minimize', gotoInternally('openfin.minimized')),
                          on('openfin.evt.popup', gotoInternally('openfin.undocked')),
                          on('openfin.evt.hdock', gotoInternally('openfin.docked_horizontal'))
                      ),
                      state('openfin.minimized',
                          onEntry(function() {
                              var main = this.main;
                              main.mainWindow.hide();
                          }),
                          on('openfin.evt.restore', gotoInternally('openfin.undocked')),
                          on('openfin.evt.popup', gotoInternally('openfin.popup'))
                      ),
                      state('openfin.popup', 
                          onEntry(function() {
                              var mainWindow = this.main.mainWindow;
                              horizDock(mainWindow);
                              mainWindow.restore(function() { focusShowBringToFront(mainWindow) });
                              var monitorRect = sandbox.windowFactory.monitorInfo.primaryMonitor.availableRect;
                              fin.desktop.System.getMousePosition(function (evt) {
                                  var x = parseInt(evt.left),
                                      y = parseInt(evt.top);
                                  var contentWindow = mainWindow.contentWindow;
                             
                                  mainWindow.moveTo(x - contentWindow.outerWidth, monitorRect.bottom - contentWindow.outerHeight);

                              });
                          }),
                          on('fund.changed', gotoInternally('openfin.minimized')),
                          on('display.changed', gotoInternally('openfin.minimized')),
                          on('date.changed', gotoInternally('openfin.minimized'))
                      ),
                      state('openfin.docked_horizontal', 
                          onEntry(function() {
                              var mainWindow = this.main.mainWindow;
                              horizDock(mainWindow);
                              
                              var monitorRect = sandbox.windowFactory.monitorInfo.primaryMonitor.availableRect;
                              var position = mainWindow.getBoundingBox();

                              mainWindow.restore(function() { focusShowBringToFront(mainWindow) });
                              
                          }),
                          on('openfin.evt.undock', gotoInternally('openfin.undocked')),
                          on('openfin.evt.popup', gotoInternally('openfin.undocked')),
                          on('openfin.evt.minimize', gotoInternally('openfin.minimized'))
                      )
            ));
        }
    };
});
