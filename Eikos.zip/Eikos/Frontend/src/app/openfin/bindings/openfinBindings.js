/*global define */
/*global fin */
/*jslint sloppy: true*/
define([
    'scalejs.sandbox!main'
], function (
    sandbox
) {
    'use strict';
    /*jshint camelcase: false */

    var raise = sandbox.state.raise,
        template = sandbox.mvvm.template;

    return {
        context_menu_show_all: function (ctx ) {
            return {
                click: function() {
                    this.openfinVM.showAllWindows([this.menuWndw]);
                    raise('openfin.evt.restore');
                    this.menuWndw.hide();
                }
            }
        },
        context_menu_exit: function (ctx ) {
            return {
                click: function() {
                    /* global fin */
                    var app = fin.desktop.Application.getCurrent();
                    app.close();
                }
            }
        },
        context_menu_hide_all: function (ctx ) {
            return {
                click: function() {
                    this.openfinVM.hideAllWindows();
                    raise('openfin.evt.minimize');
                    this.menuWndw.hide();
                }
            }
        },
        context_menu_restore: function (ctx ) {
            return {
                click: function() {
                    raise('openfin.evt.restore');
                    this.menuWndw.hide();
                }
            }
        },
        context_menu_tile: function (ctx ) {
            return {
                click: function() {
                    raise('openfin.evt.hdock');
                    this.openfinVM.tileWindows([this.menuWndw]);
                    raise('openfin.evt.restore');
                    this.menuWndw.hide();
                }
            }
        },
        ofin_header_maximize: function (ctx) {
            return {
                click: function ( ) {
                    this.wndw.undock();
                    this.wndw.maximize();
                }
            }
        },
        ofin_header_minimize: function (ctx) {
            return {
                click: function ( ) {
                    this.wndw.undock();
                    if (this.hasOwnProperty('mainWindow')) {
                        raise('openfin.evt.minimize');
                    } else {
                        this.wndw.minimize();
                    }
                }
            }
        },
        ofin_header_close: function (ctx) {
            return {
                click: function ( ) {
                    /* global fin */
                    var app = fin.desktop.Application.getCurrent();
                    if (this.hasOwnProperty('mainWindow')) {
                        app.close();
                    } else if (this.wndw.name.indexOf('Message') === 0) {
                        this.wndw.close(true, 
                                function() { console.log('close succeeded'); }, 
                                function() { console.log('close failed'); });
                    } else {
                        this.wndw.hide();
                    }

                }
            }
        },
        ofin_header_unlink: function (ctx) {
            return {
                css: {
                    hide: ! (this.wndw && this.wndw.isDocked())
                },
                click: function ( ) {
                    /* global fin */
                    var app = fin.desktop.Application.getCurrent();
                    this.wndw.undock();
                }
            }
        }
    };
});
