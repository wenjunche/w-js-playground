/*global define */
/*jslint sloppy: true*/
define([
    'scalejs.sandbox!fund',
    'knockout',
    'underscore'
], function (
    sandbox,
    ko,
    _
) {
    'use strict';
    /*jshint camelcase: false */

    var isObservable = ko.isObservable,
        raise = sandbox.state.raise;

    return {
        fund_header: function ( ctx ) {
            return {
                hmpress: {
                    time: 0,
                    handler: function () {
                        //raise('fund.back', this.drillVM());
                        raise('fund.reset', this.drillVM());
                    }
                }
            };
        },
        fund_header_title: function ( ctx ) {
            return {
                text: this.title
            }
        },
        fund_header_collateral: function ( ctx ) {
            return {
                text: this.collateral
            }
        },
        drill_level: function ( ctx ) {
            if (this.drillVM()) {
                return {
                    render: {
                        template: {
                            name: this.drillVM().template[this.display().name],
                            data: this.drillVM()
                        }
                    }
                };
            }
        },
        treemap_node_value: function ( ctx ) {
            return {
                text: this.hasOwnProperty('Position_Equivalent_MV') ? sandbox.formattedNumber.addDelimiters(this.Position_Equivalent_MV) : ''
            };
        },
        //internal use
        treemap: function ( nodeTemplate ) {
            return function ( ctx ) {
                this.data.max = Math.abs(_.max(this.data(), function (item) {
                    return Math.abs(item.Position_Equivalent_MV);
                }).Position_Equivalent_MV);
                this.data.min = Math.abs(_.min(this.data(), function (item) {
                    return Math.abs(item.Position_Equivalent_MV);
                }).Position_Equivalent_MV);
                this.data.normMin = 1;
                this.data.normMax = 15;
                return {
                    component: {
                        name: 'treemap',
                        params: {
                            data: {
                                name: '',
                                children: this.data()
                            },
                            value: function (item) {
                                var a = ctx.$data.data.normMin;
                                var b = ctx.$data.data.normMax;
                                var A = ctx.$data.data.min;
                                var B = ctx.$data.data.max;
                                var x = Math.abs(item.Position_Equivalent_MV);
                                return Math.ceil(a + (x - A) * (b - a) / (B - A));
                                //return Math.abs(item.Position_Equivalent_MV);
                            },
                            nodeTemplate: nodeTemplate
                        }
                    }
                };
            };
        }
    };
});
