/*global define */
/*jslint sloppy: true*/
define([
    'scalejs.sandbox!fund',
    'knockout',
    'app/fund/bindings/fundBindings'
], function (
    sandbox,
    ko,
    fundBindings
) {
    'use strict';
    /*jshint camelcase: false */

    var isObservable = ko.isObservable,
        raise = sandbox.state.raise;
    return {
        product_product_tab: function ( ctx ) {
            return {
                text: this.Inst_Type_Name,
                css: {
                    selected: this.Instrument_Type === ctx.$parent.product
                },
                hmpress: {
                    time: 0,
                    handler: function ( ) {
                        raise('product.selected', {
                            date: ctx.$parent.date,
                            fund: ctx.$parent.fund,
                            counterparty: ctx.$parent.cpCounterparty.counterparty,
                            product: this.Instrument_Type,
                            cpSummary: ctx.$parent.cpSummary,
                            cpCounterparty: ctx.$parent.cpCounterparty
                        });
                    }
                }
            };
        },
        product_cp_tab: function ( ctx ) {
            return {
                text: this.Counter_Party_FullName,
                css: {
                    selected: this.Counter_Party === ctx.$parent.cpCounterparty.counterparty
                },
                hmpress: {
                    time: 0,
                    handler: function () {
                        raise('counterparty.selected', {
                            date: ctx.$parent.date,
                            fund: ctx.$parent.fund,
                            counterparty: this.Counter_Party,
                            cpSummary: ctx.$parent.cpSummary
                        });
                    }
                }
            }
        },
        product_table_row: function ( ctx ) {
            return {
                hmpress: {
                    time: 50,
                    handler: function () {
                        raise('instrument.selected', {
                            date: ctx.$parent.date,
                            fund: ctx.$parent.fund,
                            counterparty: this.Counter_Party,
                            product: this.Instrument_Type,
                            instrument: this.Instrument_Name,
                            cpSummary: ctx.$parent.cpSummary,
                            cpCounterparty: ctx.$parent.cpCounterparty,
                            cpProduct: ctx.$parent
                        });
                    }
                }
            };
        },
        product_treemap_node: function ( ctx ) {
            return {
                css: {
                    positive: this.Position_Equivalent_MV > 0,
                    negative: this.Position_Equivalent_MV < 0
                },
                hmpress: {
                    time: 50,
                    handler: function ( event ) {
                            //ctx is the ctx in the treemap component
                            raise('instrument.selected', {
                                date: ctx.$root.drillVM().date,
                                fund: ctx.$root.drillVM().fund,
                                counterparty: this.Counter_Party,
                                product: this.Instrument_Type,
                                instrument: this.Instrument_Name,
                                cpSummary: ctx.$root.drillVM().cpSummary,
                                cpCounterparty: ctx.$root.drillVM().cpCounterparty,
                                cpProduct: ctx.$root.drillVM()
                            });
                    }
                }
            };
        },
        product_treemap: fundBindings.treemap('CPProduct_treemap_node_template')
    };
});
