/*global define */
/*jslint sloppy: true*/
define([
    'scalejs.sandbox!fund',
    'knockout',
    'app/fund/bindings/fundBindings'
], function (
    sandbox,
    ko,
    fundBindings
) {
    'use strict';

    var isObservable = ko.isObservable,
        raise = sandbox.state.raise;

    return {
        /*jshint camelcase: false */
        counterparty_cp_tab: function ( ctx ) {
            return {
                text: this.Counter_Party_FullName,
                css: {
                    selected: this.Counter_Party === ctx.$parent.counterparty
                },
                hmpress: {
                    time: 0,
                    handler: function ( ) {
                        raise('counterparty.selected', {
                            date: ctx.$parent.date,
                            fund: ctx.$parent.fund,
                            counterparty: this.Counter_Party,
                            cpSummary: ctx.$parent.cpSummary
                        });
                    }
                }
            }
        },
        counterparty_table_row: function ( ctx ) {
            return {
                hmpress: {
                    time: 50,
                    handler: function ( ) {
                        raise('product.selected', {
                            date: ctx.$parent.date,
                            fund: ctx.$parent.fund,
                            counterparty: this.Counter_Party,
                            product: this.Instrument_Type,
                            cpSummary: ctx.$parent.cpSummary,
                            cpCounterparty: ctx.$parent
                        });
                    }
                }
            }
        },
        counterparty_treemap_node: function ( ctx ) {
            return {
                css: {
                    positive: this.Position_Equivalent_MV > 0,
                    negative: this.Position_Equivalent_MV < 0
                },
                hmpress: {
                    time: 50,
                    handler: function ( event ) {
                        //ctx is the ctx in the treemap component
                        raise('product.selected', {
                            date: ctx.$root.drillVM().date,
                            fund: ctx.$root.drillVM().fund,
                            counterparty: this.Counter_Party,
                            product: this.Instrument_Type,
                            cpSummary: ctx.$root.drillVM().cpSummary,
                            cpCounterparty: ctx.$root.drillVM()
                        });
                    }
                }
            };
        },
        counterparty_treemap: fundBindings.treemap('CPCounterparty_treemap_node_template')
    };
});
