/*global _:false */
/*global define */
/*jslint sloppy: true*/
define([
    'scalejs.sandbox!fund',
    'knockout'
], function (
    sandbox,
    ko
) {
    'use strict';
    /*jshint camelcase: false */

    var isObservable = ko.isObservable,
        raise = sandbox.state.raise;
    return {
        details_confirm: function ( ctx ) {
            return {
                hmpress: {
                    time: 50,
                    handler: function () {
                        raise('confirm.clicked', this.data);
                    }
                }
            };
        },
        details_close: function ( ctx ) {
            return {
                hmpress: {
                    time: 50,
                    handler: function () {
                        ctx.$parent.details(null);
                    }
                }
            };
        },
        details_value: function ( ctx ) {
            var value;

            if(this.hasOwnProperty('calc') && typeof(this.calc) === 'function'){
                value = this.calc(ctx.$parent.data);
            } else {
                value = ctx.$parent.data[this.id];
            }

            if(isObservable(value)) {
                value = value();
            }

            if(this.format && _.isFunction(this.format)) {
                value = this.format(value);
            }

            return {
                text: value,
                css: this.id
            };
        },
        details_confirm_input: function ( ctx ) {
            return {
                textInput: this.data.CollateralPosted
            }
        },
    };
});
