/*global _:false */
define([
    'scalejs.sandbox!fund',
    'knockout'
], function (
    sandbox,
    ko
) {
    'use strict';
    /*jshint camelcase: false */

    var isObservable = ko.isObservable,
        raise = sandbox.state.raise;

    return {
        table_column_cell: function ( ctx ) {
            return {
                text: this.tag,
                css: this.id
            };
        },
        table_list_cell: function ( ctx ) {
            var value;

            if(this.hasOwnProperty('calc') && typeof(this.calc) === 'function'){
                value = this.calc(ctx.$parent);
            } else {
                value = ctx.$parent[this.id];
            }

            if(isObservable(value)) {
                value = value();
            }

            if(this.format && _.isFunction(this.format)) {
                value = this.format(value);
            }

            return {
                text: value,
                css: this.id
            };
        },
        table_total_cell: function ( ctx ) {
            var display_text = '';
            if(this.hasOwnProperty('total')) {
                if (!this.total) {
                    return {
                        text: '',
                        css: this.id
                    };
                }
            }

            if(!this.hasOwnProperty('total_tag')) {
                var data = sandbox.linq.enumerable.from(ctx.$parent.data());
                display_text = data.select(function (item) {
                    if (this.hasOwnProperty('calc') && typeof(this.calc) === 'function') {
                        return this.calc(item);
                    }
                    if (isObservable(item[this.id])) {
                        var value = item[this.id]();
                        if(typeof value === 'string') {
                            return sandbox.formattedNumber.removeDelimiters(value);
                        } else {
                            return value;
                        }

                    } else {
                        return item[this.id];
                    }
                }.bind(this)).sum();
                if(this.format && _.isFunction(this.format)) {
                    display_text = this.format(display_text);
                }
                //display_text = sandbox.formattedNumber.addDelimiters(display_text);
            } else {
                display_text = this.total_tag;
            }


            return {
                text: display_text,
                css: this.id
            };
        }
    };
});
