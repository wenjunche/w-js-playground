/*global define */
/*jslint sloppy: true*/
define([
    'scalejs.sandbox!fund',
    'knockout',
    'app/fund/bindings/fundBindings'
], function (
    sandbox,
    ko,
    fundBindings
) {
    'use strict';

    var isObservable = ko.isObservable,
    raise = sandbox.state.raise;
    return {
        /*jshint camelcase: false */
        details_shown: function ( ctx ) {
            return {
                css: {
                    shown: this.details()
                }
            };
        },
        tile_detail: function ( ctx ) {
            return {
                template: {
                    name: 'CPTileDetail_template',
                    data: this.details()
                }
            }
        },
        table_row_info: function ( ctx ) {
            var selected = function () {
                return ctx.$parent.details() && ctx.$parent.details().data === this;
            }.bind(this);

            return {
                hmpress: {
                    time: 50,
                    handler: function ( event ) {
                        if(selected()) {
                            ctx.$parent.details(null);
                        } else {
                            ctx.$parent.details({
                                columns: ctx.$parent.tileColumns.tileColumns,
                                wireColumns: ctx.$parent.tileColumns.wireColumns,
                                data: this
                            });
                        }
                    }
                },
                css: {
                    selected: selected()
                }
            }
        },
        table_treemap_node_info: function ( ctx ) {
            var selected = function () {
                return ctx.$root.drillVM().details() && ctx.$root.drillVM().details().data === this;
            }.bind(this);

            return {
                hmpress: {
                    time: 50,
                    handler: function ( event ) {
                        if(selected()) {
                            ctx.$root.drillVM().details(null);
                        } else {
                            ctx.$root.drillVM().details({
                                columns: ctx.$root.drillVM().tileColumns.tileColumns,
                                wireColumns: ctx.$root.drillVM().tileColumns.wireColumns,
                                data: this
                            });
                        }
                    }
                },
                css: {
                    selected: selected()
                }
            }
        },
        summary_table_row: function ( ctx ) {
            return {
                hmpress: {
                    time: 50,
                    handler: function ( event ) {
                        if (event.target.className.substr(0, 2) === 'fa') {
                            return;
                        }
                        raise('counterparty.selected', {
                            date: ctx.$parent.date,
                            fund: ctx.$parent.fund,
                            counterparty: this.Counter_Party,
                            cpSummary: ctx.$parent
                        });
                    }
                }
            };
        },
        summary_treemap_node: function ( ctx ) {
            return {
                if: this.Position_Equivalent_MV,
                css: {
                    positive: this.Position_Equivalent_MV > 0,
                    negative: this.Position_Equivalent_MV < 0
                },
                hmpress: {
                    time: 50,
                    handler: function ( event ) {
                        if (event.target.className.substr(0, 2) === 'fa') {
                            return;
                        }
                        if(this.Counter_Party) {
                            //ctx is the ctx in the treemap component
                            raise('counterparty.selected', {
                                date: ctx.$root.drillVM().date,
                                fund: ctx.$root.drillVM().fund,
                                counterparty: this.Counter_Party,
                                cpSummary: ctx.$root.drillVM()
                            });
                        }
                    }
                }
            };
        },
        summary_treemap: fundBindings.treemap('CPSummary_treemap_node_template')
    };
});
