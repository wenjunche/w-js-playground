/*global define */
/*global _:false */
define([
    'scalejs.sandbox!fund',
    'app/fund/viewmodels/fundViewModel',
    'bindings!fund',
    'bindings!CPSummaryBindings',
    'bindings!CPTileDetailBindings',
    'bindings!CPCounterpartyBindings',
    'bindings!CPProductBindings',
    'bindings!tableBindings',
    'views!fund',
    'views!./views/CPSummary/CPSummary',
    'views!./views/CPSummary/CPSummary_tile',
    'views!./views/CPSummary/CPSummary_treemap',
    'views!./views/CPSummary/CPTileDetail',
    'views!./views/CPSummary/CPSummaryConfirmModal',
    'views!./views/CPCounterparty/CPCounterparty',
    'views!./views/CPCounterparty/CPCounterparty_tile',
    'views!./views/CPCounterparty/CPCounterparty_treemap',
    'views!./views/CPProduct/CPProduct',
    'views!./views/CPProduct/CPProduct_tile',
    'views!./views/CPProduct/CPProduct_treemap',
    'views!./views/CPProduct/CPTradeDetail',
    'styles!./styles/fund',
    'styles!./styles/CPSummary',
    'styles!./styles/CPTileDetail',
    'styles!./styles/CPSummaryConfirmModal',
    'styles!./styles/CPCounterparty',
    'styles!./styles/CPProduct',
    'styles!./styles/CPTradeDetail'
], function (
    sandbox,
    fundViewModel
) {
    'use strict';

    return function fund() {
        var // imports
            root = sandbox.mvvm.root,
            template = sandbox.mvvm.template,
            registerStates = sandbox.state.registerStates,
            goto = sandbox.state.builder.goto,
            gotoInternally = sandbox.state.builder.gotoInternally,
            on = sandbox.state.builder.on,
            routerState = sandbox.routing.routerState,
            route = sandbox.routing.route,
            state = sandbox.state.builder.state,
            raise = sandbox.state.raise,
            onEntry = sandbox.state.builder.onEntry,
            observable = sandbox.mvvm.observable,
            // vars
            fund,
            fundVms = {},
            isOpenFin = typeof(fin) !== 'undefined';
            // fund = fundViewModel('egmf', 'EGMF', valueDate);

            function createFund(fund, funds, e) {
                if (!fund || fund.fund !== e.data.fund || fund.date !== e.data.date) {
                    var x = {};
                    x.FundNameTicker = e.data.fund;
                    var fundData = _.chain(funds).where(x).first().value();
                    if (fundVms.hasOwnProperty(e.data.fund)) {
                        fund = fundVms[e.data.fund].update(fundData, e.data.date, this.display);
                    } else {
                        fund = fundViewModel(fundData, e.data.date, this.display);
                    }
                }
                fundVms[e.data.fund] = fund;
                if (isOpenFin && ! fund.hasOwnProperty('message')) {
                    fund.message = observable();
                }

                return fund;
            }


        // Register application state for the module.
        registerStates('main',
            state('fund',
                state('fund.waiting',
                    //route('/'),
                    onEntry(function () {
                        fund = null;
                    }),
                    on('fund.selected', gotoInternally('fund.summary'))
                ),
                state('fund.summary',
                    //route('date/{date}/fund/{fund}'),
                    onEntry(function (e) {
                        e.data.date = this.valueDate;
                        if (this.isOpenFin) {
                            if(e.name === 'date.changed') {
                                for(var fundName in fundVms) {
                                    if (fundVms.hasOwnProperty(fundName)){
                                        var fundVm = fundVms[fundName];
                                        fundVm.summary({date: fundVm.date, fund: fundVm.fund});
                                    }
                                }
                            } else {
                                fund = createFund.apply(this, [fund, this.funds(), e]);
                                fund.summary(e.data);
                                this.region(template('fund_template', fund));
                                this.header(template('fund_header_template', fund));
                                if (!fund.hasOwnProperty('wndw')) {
                                    var child = sandbox.windowFactory.createWindow({
                                        name: 'Collateral Details' + fund.fund,
                                        url: window.baseUrl + '/details.html',
                                        defaultWidth: 1140,
                                        defaultHeight: 550,
                                        renderable: template('openfin_fund_template', fund)
                                    });
                                    child.onReady(function() {
                                        child.show();
                                    });
                                    fund.wndw = child;
                                } else {
                                    fund.wndw.show();
                                    fund.wndw.bringToFront();
                                    fund.wndw.focus();
                                }
                            }
                        } else {
                            fund = createFund.apply(this, [fund, this.funds(), e]);
                            fund.summary(e.data);
                            this.region(template('fund_template', fund));
                            this.header(template('fund_header_template', fund));
                        }
                        console.log('summary', e.data);
                    }),
                    on('fund.changed', gotoInternally('fund.summary')),
                    on('date.changed', gotoInternally('fund.summary')),
                    on('counterparty.selected', gotoInternally('fund.counterparty')),
                    on('confirm.clicked', gotoInternally('fund.confirm'))
                ), //state 'fund.summary'
                state('fund.confirm',
                    state('fund.confirm.waiting',
                        onEntry(function (e) {
                          e.data.fund = e.data.FundNameTicker;
                          e.data.date = this.valueDate;
                          fund = createFund.apply(this, [fund, this.funds(), e]);
                          raise('message.show', {
                              /* jshint camelcase: false */
                              title: 'Please Confirm: ' + e.data.Counter_Party_FullName,
                              class: 'CPSummary_fund_confirm',
                              region: template('CPSummary_fund_confirm_modal_template', {
                                  columns: fund.cpSummary.columns,
                                  data: e.data
                              }),
                              buttons: ['OK', 'Cancel'],
                              fundvm: fund
                          });
                        }),
                        on('message.OK', gotoInternally('fund.post')),
                        on('message.Cancel', gotoInternally('fund.summary')),
                        on('message.close', gotoInternally('fund.summary'))
                    ), // state 'fund.confirm.waiting'
                    on('fund.changed', gotoInternally('fund.summary')),
                    on('date.changed', gotoInternally('fund.summary')),
                    on('counterparty.selected', gotoInternally('fund.counterparty')),
                    on('confirm.clicked', gotoInternally('fund.confirm'))
                ), //state 'fund.confirm'
                state('fund.post',
                    onEntry(function(e) {
                        fund.postChanges(e.data);
                    }),
                    state('fund.post.waiting',
                      onEntry(function (e) {
                        console.log('fund.post.waiting', e);
                      }),
                      on('post.complete', gotoInternally('fund.summary'))
                    )
                ), //state 'fund.post'
                state('fund.counterparty',
                    //route('date/{date}/fund/{fund}/counterparty/{counterparty}'),
                    onEntry(function (e) {
                        e.data.date = this.valueDate;
                        fund = createFund.apply(this, [fund, this.funds(), e]);
                        fund.drill1(e.data)
                        //this.region(template('fund_template', fund.drill1(e.data)));
                        console.log('counterparty', e.data);

                    }),
                    on('fund.changed', gotoInternally('fund.summary')),
                    on('date.changed', gotoInternally('fund.summary')),
                    on('counterparty.selected', gotoInternally('fund.counterparty')),
                    on('product.selected', gotoInternally('fund.product')),
                    on('fund.back', gotoInternally('fund.summary')),
                    on('confirm.clicked', gotoInternally('fund.confirm')),
                    on('fund.reset', gotoInternally('fund.summary'))
                ), //state 'fund.counterparty'
                state('fund.product',
                    //route('date/{date}/fund/{fund}/counterparty/{counterparty}/product/{product}'),
                    onEntry(function (e) {
                        e.data.date = this.valueDate;
                        fund = createFund.apply(this, [fund, this.funds(), e]);
                        fund.drill2(e.data)
                        //this.region(template('fund_template', fund.drill2(e.data)));
                        console.log('product', e.data);

                    }),
                    state('fund.product.summary',
                        on('instrument.selected', gotoInternally('fund.product.tradedetail'))
                    ), //state 'fund.product.summary'
                    state('fund.product.tradedetail',
                        //route('date/{date}/fund/{fund}/counterparty/{counterparty}/product/{product}/instrument/{instrument}'),
                        onEntry(function (e) {
                            var tradeDetailVM = fund.getTradeDetail(e.data);
                            raise('message.show', {
                                title: 'Trade Details: ' + tradeDetailVM.getUniqueKey(),
                                class: 'CPProduct_tradedetail',
                                region: template(tradeDetailVM.template, tradeDetailVM),
                                fundvm: fund,
                                close: true,
                                popout: true
                                //buttons: ['OK'],
                            });
                        }),
                        on('message.OK', gotoInternally('fund.product.summary')),
                        on('message.close', gotoInternally('fund.product.summary'))
                    ), //state 'fund.product.tradedetail'
                    on('fund.changed', gotoInternally('fund.summary')),
                    on('date.changed', gotoInternally('fund.summary')),
                    on('counterparty.selected', gotoInternally('fund.counterparty')),
                    on('product.selected', gotoInternally('fund.product')),
                    on('instrument.selected', gotoInternally('fund.product.tradedetail')),
                    on('fund.back', gotoInternally('fund.counterparty')),
                    on('confirm.clicked', gotoInternally('fund.confirm')),
                    on('fund.reset', gotoInternally('fund.summary'))
                ), // state 'fund.product'
                on('message.OK', gotoInternally('fund.post'))
            ) // state 'fund'
        ) // state 'main'
    };
});
