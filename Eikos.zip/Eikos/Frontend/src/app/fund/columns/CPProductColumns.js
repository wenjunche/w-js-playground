define([
    'scalejs.sandbox!fund',
    'underscore'
], function (
    sandbox,
    _
) {
    'use strict';
    /*jshint camelcase: false */

    return [
        {
            id: 'Instrument_Name',
            tag: 'Underlier',
            total_tag: 'Totals:'
        },
        {
            id: 'Position_Equivalent_IM',
            tag: 'EP Macro IM',
            format: _.compose(sandbox.formattedNumber.addDelimiters,
                              sandbox.formattedNumber.removeDecimal)
        },
        {
            id: 'CP_Position_Equivalent_IM',
            tag: 'CP IM',
            format: _.compose(sandbox.formattedNumber.addDelimiters,
                              sandbox.formattedNumber.removeDecimal)
        },
        {
            id: 'DeltaIM',
            tag: 'Delta IM',
            format: _.compose(sandbox.formattedNumber.addDelimiters,
                              sandbox.formattedNumber.removeDecimal)
        },
        {
            id: 'Position_Equivalent_MV',
            tag: 'EP Macro MV',
            format: _.compose(sandbox.formattedNumber.addDelimiters,
                              sandbox.formattedNumber.removeDecimal)
        },
        {
            id: 'CP_Position_Equivalent_MV',
            tag: 'CP MV',
            format: _.compose(sandbox.formattedNumber.addDelimiters,
                              sandbox.formattedNumber.removeDecimal)
        },
        {
            id: 'DeltaMV',
            tag: 'Delta MV',
            format: _.compose(sandbox.formattedNumber.addDelimiters,
                              sandbox.formattedNumber.removeDecimal)
        }
    ];
});
