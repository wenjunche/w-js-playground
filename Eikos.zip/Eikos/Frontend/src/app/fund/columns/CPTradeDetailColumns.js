// CPInstName: "GM 2030-03-15 @325"
// CPSpread: 1.497
// CPTradeID: "IB410362"
// CP_Position_Equivalent_IM: 26250000
// CP_Position_Equivalent_MV: -44923158.71
// DeltaIM: -3000000
// DeltaMVPercent: 57.0195573000383
// Direction: "S"
// Instrument_Name: "GM 2030-03-15 @325"
// MatchID: "M10362"
// Position: 30000
// Position_Equivalent: 30000000
// Position_Equivalent_IM: 23250000
// Position_Equivalent_MV: -104520000
// Settle_Date: "2015-03-12T00:00:00.000Z"
// Spread: 3.484
// TradeID: "10362"
// Trade_Date: "2015-03-09T00:00:00.000Z"

define([
    'scalejs.sandbox!fund',
    'underscore'
], function (
    sandbox,
    _
) {
    'use strict';
    /*jshint camelcase: false */

    return [
        {
            id: 'Spread',
            tag: 'Spread',
            total_tag: 'Totals:'
        },
        {
            id: 'CPSpread',
            tag: 'CPSpread',
            total: false
        },
        {
            id: 'Position_Equivalent_MV',
            tag: 'Position_Equivalent_MV',
            format: _.compose(sandbox.formattedNumber.addDelimiters,
                              sandbox.formattedNumber.removeDecimal)
        },
        {
            id: 'CP_Position_Equivalent_MV',
            tag: 'CP_Position_Equivalent_MV',
            format: _.compose(sandbox.formattedNumber.addDelimiters,
                              sandbox.formattedNumber.removeDecimal)
        },
        {
            id: 'DeltaMVPercent',
            tag: 'DeltaMVPercent',
            format: function (value) {
                return value.toFixed(2) + ' %';
            },
            total: false
        },
        {
            id: 'Position_Equivalent_IM',
            tag: 'Position_Equivalent_IM',
            format: _.compose(sandbox.formattedNumber.addDelimiters,
                              sandbox.formattedNumber.removeDecimal)
        },
        {
            id: 'CP_Position_Equivalent_IM',
            tag: 'CP_Position_Equivalent_IM',
            format: _.compose(sandbox.formattedNumber.addDelimiters,
                              sandbox.formattedNumber.removeDecimal)
        },
        {
            id: 'DeltaIM',
            tag: 'Delta IM',
            format: _.compose(sandbox.formattedNumber.addDelimiters,
                              sandbox.formattedNumber.removeDecimal)
        },
        {
            id: 'Instrument_Name',
            tag: 'Instrument_Name',
            total: false
        },
        {
            id: 'CPInstName',
            tag: 'CPInstName',
            total: false
        },
        {
            id: 'Direction',
            tag: 'Direction',
            total: false
        },
        {
            id: 'Position',
            tag: 'Position',
            format: _.compose(sandbox.formattedNumber.addDelimiters,
                              sandbox.formattedNumber.removeDecimal)
        },
        {
            id: 'Position_Equivalent',
            tag: 'Position_Equivalent',
            format: _.compose(sandbox.formattedNumber.addDelimiters,
                              sandbox.formattedNumber.removeDecimal)
        },
        {
            id: 'Trade_Date',
            tag: 'Trade_Date',
            format: function (value) {
                return value.substring(0, 10);
            },
            total: false
        },
        {
            id: 'Settle_Date',
            tag: 'Settle_Date',
            format: function (value) {
                return value.substring(0, 10);
            },
            total: false
        },
        {
            id: 'TradeID',
            tag: 'TradeID',
            total: false
        },
        {
            id: 'CPTradeID',
            tag: 'CPTradeID',
            total: false
        },
        {
            id: 'MatchID',
            tag: 'MatchID',
            total: false
        },
    ];
});
