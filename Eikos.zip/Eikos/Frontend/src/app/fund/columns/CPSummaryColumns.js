define([
    'scalejs.sandbox!fund',
    'underscore'
], function (
    sandbox,
    _
) {
    'use strict';
    /*jshint camelcase: false */

    return [
        {
            id: 'Counter_Party_FullName',
            tag: 'Counter Party',
            total_tag: 'Totals:'
        },
        {
            id: 'Position_Equivalent_IM',
            tag: 'EP Macro IM',
            format: _.compose(sandbox.formattedNumber.addDelimiters,
                              sandbox.formattedNumber.removeDecimal)
        },
        {
            id: 'Position_Equivalent_MV',
            tag: 'EP Macro MV',
            format: _.compose(sandbox.formattedNumber.addDelimiters,
                              sandbox.formattedNumber.removeDecimal)
        },
        {
            id: 'Position_Equivalent_Total',
            tag: 'EP Macro Ttl',
            format: _.compose(sandbox.formattedNumber.addDelimiters,
                              sandbox.formattedNumber.removeDecimal)
        },
        {
            id: 'CollateralTotal',
            tag: 'Coll Post/Hold',
            format: _.compose(sandbox.formattedNumber.addDelimiters,
                              sandbox.formattedNumber.removeDecimal)
        },
        {
            id: 'CallorReturn',
            tag: 'Est. Call/Return',
            format: _.compose(sandbox.formattedNumber.addDelimiters,
                              sandbox.formattedNumber.removeDecimal)
        },
        {
            id: 'CP_Position_Equivalent_Total',
            tag: 'CP Total',
            format: _.compose(sandbox.formattedNumber.addDelimiters,
                              sandbox.formattedNumber.removeDecimal)
        },
        {
            id: 'CollateralPosted',
            tag: 'Call/Return',
            format: _.compose(sandbox.formattedNumber.addDelimiters,
                              sandbox.formattedNumber.removeDecimal)
        },
    ];
});
