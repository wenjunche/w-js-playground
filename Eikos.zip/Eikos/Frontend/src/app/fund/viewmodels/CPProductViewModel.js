/*global define */
define([
    'scalejs.sandbox!fund',
    'underscore',
    '../columns/CPProductColumns'
], function (
    sandbox,
    _,
    columns
) {
    'use strict';
    /*jshint camelcase: false */

    return function (data) {
        var observable = sandbox.mvvm.observable,
            observableArray = sandbox.mvvm.observableArray,
            computed = sandbox.mvvm.computed,
            valueDate = data.date,
            fundNameTicker = data.fund,
            counterparty = data.counterparty,
            product = data.product,
            cpSummary = data.cpSummary,
            cpCounterparty = data.cpCounterparty,
            counterpartyRow = _.chain(cpSummary.data()).where({Counter_Party: counterparty}).first().value(),
            instruments = cpCounterparty.data(),
            instrumentDetails = observableArray([]);

        sandbox.query('/CollateralMgmtCPInst/' + valueDate() + '/' + fundNameTicker + '/' + counterparty + '/' + product, function (error, data) {
            if (error) {
                console.error(error);
                return;
            }

            instrumentDetails(data);

        });

        return {
            template: {
                table: 'CPProduct_template',
                tile: 'CPProduct_tile_template',
                treemap: 'CPProduct_treemap_template'
            },
            fund: fundNameTicker,
            date: valueDate,
            counterparty: counterparty,
            product: product,
            cpSummary: cpSummary,
            cpCounterparty: cpCounterparty,
            counterpartyRow: counterpartyRow,
            instruments: instruments,
            columns: columns,
            data: instrumentDetails
        };
    };
});
