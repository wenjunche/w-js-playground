/*global define */
define([
    'scalejs.sandbox!fund',
    'underscore',
    '../columns/CPSummaryColumns',
    '../columns/CPTileDetailColumns'
], function (
    sandbox,
    _,
    columns,
    tileColumns
) {
    'use strict';
    /*jshint camelcase: false */

    return function (data) {
        var observable = sandbox.mvvm.observable,
            observableArray = sandbox.mvvm.observableArray,
            computed = sandbox.mvvm.computed,
            raise = sandbox.state.raise,
            selectedCounterparty = observable(null),
            valueDate = data.date,
            fundNameTicker = data.fund,
            collateral = observable(''),
            details = observable(),
            selectedCounterpartyVM,
            orders = observableArray([]);

        computed(function () {
            sandbox.query('/CollateralMgmt/' + valueDate() + '/' + fundNameTicker, function (error, data) {
                if (error) {
                    console.error(error);
                    return;
                }

                // var CollateralTotalNewColumn = _.where(columns, {id: 'CollateralTotalNew'}).first();

                _.map(data, function ( row ) {
                    //TODO: figure out why backend returns string instead of int
                    row['Position_Equivalent_MV'] = parseInt(row['Position_Equivalent_MV']);
                    row['CP_Position_Equivalent_MV'] = parseInt(row['CP_Position_Equivalent_MV']);
                    row['CollateralPosted'] = observable(row['CollateralPosted']).extend({formattedNumber: true});

                    // if(row['CollateralTotalNew'] !== CollateralTotalNewColumn.calc(row)) {
                    //     console.error('CollateralTotalnew is not being calculated correctly!:\n',
                    //         row, '\n',
                    //         'row.CollateralTotalNew =', row['CollateralTotalNew'], '\n',
                    //         'calc =', CollateralTotalNewColumn.calc(row));
                    // } else {
                    //     console.log('Calc was correct.');
                    // }

                });

                var collateralSum = _.reduce(data, function (memo, row) {
                    return memo + row.Collateral;
                }, 0);

                collateral(sandbox.global.toolkit.filter.bn(collateralSum));

                orders(data);

                if(selectedCounterparty() !== null) {
                    var found = _.find(data, function ( item ) {
                        return item.Counter_Party === selectedCounterparty().Counter_Party;
                    });
                    if (found) {
                        selectedCounterparty(found);
                    } else {
                        selectedCounterparty(null);
                    }
                }

            });
        });


        function post(data) {
            //@ValueDate = valueDate,
            //@Collateral = e.data.CollateralPosted
            //@CollateralType = e.data.Collateral_Type
            //@CounterParty = e.data.Counter_Party
            //@FundNameTicker = fundNameTicker

            sandbox.post('/UpdateFundCollBalance/' +
              valueDate() + '/' +
              fundNameTicker + '/' +
              data.Counter_Party + '/' +
              sandbox.formattedNumber.removeDelimiters(data.CollateralPosted()) + '/' +
              data.Collateral_Type,
              function (error, data) {
                if (error) {
                    console.error(error);
                    raise('post.error', error);
                    return;
                }

                raise('post.complete', {date: valueDate(), fund: fundNameTicker});

            });


        }

        return {
            template: {
                table: 'CPSummary_template',
                tile: 'CPSummary_tile_template',
                treemap: 'CPSummary_treemap_template'
            },
            fund: fundNameTicker,
            date: valueDate,
            collateral: collateral,
            columns: columns,
            tileColumns: tileColumns,
            details: details,
            data: orders,
            post: post
        };
    };
});
