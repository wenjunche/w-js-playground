/*global define */
define([
    'scalejs.sandbox!fund',
    'underscore',
    '../columns/CPTradeDetailColumns'
], function (
    sandbox,
    _,
    columns
) {
    'use strict';
    /*jshint camelcase: false */

    return function (data) {
        var observable = sandbox.mvvm.observable,
            observableArray = sandbox.mvvm.observableArray,
            computed = sandbox.mvvm.computed,
            valueDate = data.date,
            fundNameTicker = data.fund,
            counterparty = data.counterparty,
            product = data.product,
            instrument = data.instrument,
            cpSummary = data.cpSummary,
            cpCounterparty = data.cpCounterparty,
            cpProduct = data.cpProduct,
            counterpartyRow = _.chain(cpSummary.data()).where({Counter_Party: counterparty}).first().value(),
            instruments = cpCounterparty.data(),
            // columns = observableArray([]),
            tradeDetail = observableArray([]);

        //computed(function () {
        sandbox.query('/CollateralMgmtCPTradeDetail/'
                        + valueDate() + '/'
                        + fundNameTicker + '/'
                        + counterparty + '/'
                        + product + '/'
                        + instrument, function (error, data) {
            if (error) {
                console.error(error);
                return;
            }

            // columns(_.chain(data).first().keys().map(function (property) {
            //     return {
            //         id: property,
            //         tag: property
            //     };
            // }).value());
            // for(var i = 1; i < 100; i++) {
            //     data[i] = data[0];
            // }
            tradeDetail(data);

        });
        //});
        var getUniqueKey = function() {
            return fundNameTicker + '/' + counterparty + '/' + product + '/' + instrument;
        }


        return {
            template: 'CPTradeDetail_template',
            fund: fundNameTicker,
            date: valueDate,
            counterparty: counterparty,
            product: product,
            instrument: instrument,
            cpSummary: cpSummary,
            cpCounterparty: cpCounterparty,
            cpProduct: cpProduct,
            counterpartyRow: counterpartyRow,
            instruments: instruments,
            columns: columns,
            data: tradeDetail,
            getUniqueKey: getUniqueKey
        };
    };
});
