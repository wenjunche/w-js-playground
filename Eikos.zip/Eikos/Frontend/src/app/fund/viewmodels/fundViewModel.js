
/*global define */
define([
    'scalejs.sandbox!fund',
    './CPSummaryViewModel',
    './CPCounterpartyViewModel',
    './CPProductViewModel',
    './CPTradeDetailViewModel'
], function (
    sandbox,
    CPSummaryViewModel,
    CPCounterpartyViewModel,
    CPProductViewModel,
    CPTradeDetailViewModel
) {
    'use strict';
    /*jshint camelcase: false */

    //{CollateralTotal: 195000000,
    //FundName: "EIKOS COMMODITIES FUND",
    //FundNameTicker: "ECF"}
    return function (fundData, valueDate, display) {
        var observable = sandbox.mvvm.observable,
            drillVM = observable(),
            cpSummary = new CPSummaryViewModel({fund: fundData.FundNameTicker, date: valueDate});

        function summary(e) {
            cpSummary = new CPSummaryViewModel(e);
            drillVM(cpSummary);
        }

        function drill1(e) {
            drillVM(new CPCounterpartyViewModel(e));
        }

        function drill2(e) {
            drillVM(new CPProductViewModel(e));
        }

        function getTradeDetail(e) {
            return new CPTradeDetailViewModel(e);
        }

        function postChanges(e) {
            cpSummary.post(e);
        }

        function update(fundData, valueDate, display) {
            this.title = fundData.FundName;
            this.fund = fundData.FundNameTicker;
            this.date = valueDate;
            this.collateral = sandbox.global.toolkit.filter.bn(fundData.CollateralTotal);
            this.display = display;
            return this;
        }


        return {
            title: fundData.FundName,
            title_template: 'fund_header',
            fund: fundData.FundNameTicker,
            date: valueDate,
            collateral: sandbox.global.toolkit.filter.bn(fundData.CollateralTotal),
            drillVM: drillVM,
            summary: summary,
            cpSummary: cpSummary,
            drill1: drill1,
            drill2: drill2,
            display: display,
            getTradeDetail: getTradeDetail,
            postChanges: postChanges,
            update: update
        };
    };
});
