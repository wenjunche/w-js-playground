/*global define */
define([
    'scalejs.sandbox!fund',
    'underscore',
    '../columns/CPCounterpartyColumns'
], function (
    sandbox,
    _,
    columns
) {
    'use strict';
    /*jshint camelcase: false */

    return function (data) {
        var observable = sandbox.mvvm.observable,
            observableArray = sandbox.mvvm.observableArray,
            computed = sandbox.mvvm.computed,
            valueDate = data.date,
            fundNameTicker = data.fund,
            counterparty = data.counterparty,
            cpSummary = data.cpSummary,
            counterpartyRow = _.chain(cpSummary.data()).where({Counter_Party: counterparty}).first().value(),
            selectedProduct,
            instruments = observableArray([]);

        sandbox.query('/CollateralMgmtCP/' + valueDate() + '/' + fundNameTicker + '/' + counterparty, function (error, data) {
            if (error) {
                console.error(error);
                return;
            }

            instruments(data);

        });

        return {
            template: {
                table: 'CPCounterparty_template',
                tile: 'CPCounterparty_tile_template',
                treemap: 'CPCounterparty_treemap_template'
            },
            fund: fundNameTicker,
            date: valueDate,
            counterparty: counterparty,
            cpSummary: cpSummary,
            counterpartyRow: counterpartyRow,
            columns: columns,
            data: instruments,
        };
    };
});
