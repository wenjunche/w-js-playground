/*global define */
define([
    'scalejs.sandbox!main',
    'underscore'
], function (
    sandbox,
    _
) {
    'use strict';

    return function () {
        var observable = sandbox.mvvm.observable,
            observableArray = sandbox.mvvm.observableArray,
            template = sandbox.mvvm.template,
            computed = sandbox.mvvm.computed,
            raise = sandbox.state.raise,
            messages = observableArray([]),
            isOpenFin = typeof(fin) !== 'undefined';

        //remove first element in message()
        function hideMessage(e)
        {
            //e.data is the name of the button clicked
            if (isOpenFin) {
                raise('message.' + e.data.name, e.data.data.region.template.data.data);
                // e.data.data.wndw.close(true);
                e.data.data.fundvm.message(null);
            } else {
                var message = messages.pop();
                raise('message.' + e.data.name, message.region.template.data.data);  //used by caller of message (message.OK, message.Cancel, etc)
            }
        }

        // close button clicked: dont raise any other event
        function closeMessage(e) {
            if (isOpenFin) {
                e.data.fundvm.message(null);
            } else {
                messages.pop();
            }
        }

        //push message to front of message()
        function showMessage(e)
        {
            if (isOpenFin) {
                var vm = e.data;
                e.data.fundvm.message(template('openfin_message_template', vm));
            } else {
                messages.push(e.data);
            }
        }

        //pop out into it's own openfin window
        function popoutMessage(e)
        {
            if (isOpenFin) {
                //make a clone and remove the fundvm because you can't pass a reference 
                //to an openfin window into a createWindow and fundvm contains wndw property
                var vm = _.clone(e.data);
                vm.fundvm = null;

                var child = sandbox.windowFactory.createWindow({
                    name: 'Message' + e.data.title,
                    url: window.baseUrl + '/details.html',
                    defaultWidth: 1140,
                    defaultHeight: 550,
                    //fitToElement: '#message',
                    renderable: template('openfin_popout_message_template', vm)
                });
                vm.wndw = child;
                child.onReady(function() {
                    child.show();
                });
                e.data.fundvm.message(null);
            }
        }

        return {
          hideMessage: hideMessage,
          closeMessage: closeMessage,
          showMessage: showMessage,
          messages: messages,
          popoutMessage: popoutMessage
        };
      }
});
