/*global define */
/*jslint sloppy: true*/
define([
    'scalejs.sandbox!message',
    'underscore'
], function (
    sandbox,
    _
) {
    'use strict';
    var raise = sandbox.state.raise;
    return {
        /*jshint camelcase: false */
        message_class: function ( ctx ) {
            return {
                css: this.class ? this.class : ''
            };
        },
        message_title: function ( ctx ) {
            return {
                text: this.title
            }
        },
        message_background: function ( ctx ) {
            return {
                hmpress: {
                    time: 50,
                    handler: function () {
                        var message = _.last(this.messages());
                        if(message.close || message.close === undefined) {
                            raise('message.close', message);
                        }
                    }
                }
            };
        },
        message_close: function ( ctx ) {
            return {
                hmpress: {
                    time: 50,
                    handler: function () {
                        raise('message.close', this);
                    }
                }
            };
        },
        message_popout: function ( ctx ) {
            return {
                hmpress: {
                    time: 50,
                    handler: function () {
                        raise('message.popout', this);
                    }
                }
            };
        },
        message_button: function ( ctx ) {
            return {
                text: this,
                hmpress: {
                    time: 50,
                    handler: function () {
                        raise('message.hide', {name: this, data: ctx.$parent});
                    }
                }
            }
        },
        message_input_name: function ( ctx ) {
            return {
                text: this.name
            };
        },
        message_input: function ( ctx ) {
            return {
                textInput: this.value
            };
        }
    };
});
