/*global define */
define([
    'scalejs.sandbox!message',
    'app/message/viewmodels/messageViewModel',
    'bindings!message',
    'views!message',
    'styles!./styles/message'
], function (
    sandbox,
    messageViewModel
) {
    'use strict';

    return function message() {
        var // imports
            root = sandbox.mvvm.root,
            template = sandbox.mvvm.template,
            registerStates = sandbox.state.registerStates,
            routerState = sandbox.routing.routerState,
            route = sandbox.routing.route,
            state = sandbox.state.builder.state,

            onEntry = sandbox.state.builder.onEntry,
            on = sandbox.state.builder.on,
            // vars
            message = messageViewModel(sandbox);

            // Register application state for the module.
            registerStates('app',
                state('message',
                    onEntry(function (e) {
                        this.message(template('message_template', message));
                    }),
                    on('message.show', function (e) {
                        message.showMessage(e);
                    }),
                    on('message.popout', function (e) {
                        message.popoutMessage(e);
                    }),
                    on('message.hide', function (e) {
                        message.hideMessage(e);
                    }),
                    on('message.close', function (e) {
                        message.closeMessage(e);
                    })));
    };
});
