/*global define */
/*global fin */
define([
    'scalejs.sandbox!main',
    'app/main/viewmodels/mainViewModel',
    'knockout',
    'bindings!main',
    'views!main',
    'styles!./styles/main'
], function (
    sandbox,
    mainViewModel,
    ko
) {
    'use strict';
    /*jshint camelcase: false */

    return function main() {
        var // imports
            root = sandbox.mvvm.root,
            template = sandbox.mvvm.template,
            registerStates = sandbox.state.registerStates,
            routerState = sandbox.routing.routerState,
            route = sandbox.routing.route,
            state = sandbox.state.builder.state,
            parallel = sandbox.state.builder.parallel,
            onEntry = sandbox.state.builder.onEntry,
            // vars
            main = mainViewModel(sandbox),
            isOpenFin = typeof(fin) !== 'undefined';

        // Register application state for the module.
        registerStates('root',
                parallel('app',//routerState('app',
                  onEntry(function () {
                    this.message = main.message;
                    this.main = main;
                  }),
                  state('main', //route('/'),
                      onEntry(function () {
                          this.funds = main.funds;
                          this.region = main.region;
                          this.header = main.header;
                          this.valueDate = main.valueDate;
                          this.display = main.display;
                          this.isOpenFin = isOpenFin;
                          if (!isOpenFin) {
                              root(template('main_template', main));
                          }
                      }))
                  ));
    };
});
