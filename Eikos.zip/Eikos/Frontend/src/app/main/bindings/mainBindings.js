/*global define */
/*jslint sloppy: true*/
define([
    'scalejs.sandbox!main'
], function (
    sandbox
) {
    'use strict';
    /*jshint camelcase: false */

    var raise = sandbox.state.raise,
        template = sandbox.mvvm.template;

    return {
        main_panel: function ( ctx ) {
            return {
                css: this.selecting
            }
        },
        display_option: function ( ctx ) {
            var css = {
                selected: sandbox.mvvm.computed(function ( ) {
                    return this.name === ctx.$parent.display().name;
                }.bind(this))
            };
            css['btn-icon vertical fa fa-' + this.class] = true;
            return {
                css: css,
                hmpress: {
                    time: 0,
                    handler: function ( ) {
                        ctx.$parent.display(this);
                    }
                }
            };
        },
        action_option: function ( ctx ) {
            var css = {
                selected: sandbox.mvvm.computed(function ( ) {
                    return this.name === ctx.$parent.display().name;
                }.bind(this))
            };
            css['btn-icon vertical fa fa-' + this.class] = true;
            return {
                css: css,
                hmpress: {
                    time: 0,
                    handler: function ( ) {
                        ctx.$parent.display(this);
                    }
                }
            };
        },
        display_container: function ( ctx ) {
            return {
                css: this.display().name
            };
        },
        sidebar_datepicker: function ( ctx ) {
            return {
                options: this.availableDates,
                value: this.valueDate
            };
        },
        sidebar_datepicker_date: function ( ctx ) {
            return {
                attr: {
                    value: this
                },
                text: this
            };
        },
        sidebar_toggle: function ( ctx ) {
            var shown = false;

            return {
                hmpress: {
                    time: 0,
                    handler: function ( ) {
                        shown = !shown;

                        if (shown) {
                            this.selecting('selecting');
                        } else {
                            this.selecting('');
                        }
                    }
                }
            };
        },
        sidebar_tile: function ( ctx ) {
            return {
                css: {
                    selected: ctx.$parent.selectedFund() === this
                },
                hmpress: {
                    time: 0,
                    handler: function ( ) {
                        ctx.$parent.selectedFund(this);
                        raise('fund.changed', {
                            date: ctx.$parent.valueDate(),
                            fund: this.FundNameTicker
                        });
                        ctx.$parent.selecting('');
                    }
                }
            };
        },
        sidebar_tile_icon: function ( ctx ) {
            return {
                css: 'fa fa-' + this.Icon
            }
        },
        sidebar_tile_name: function ( ctx ) {
            return {
                text: this.FundNameTicker
            }
        },
        sidebar_tile_value: function ( ctx ) {
            return {
                text: sandbox.global.toolkit.filter.bn(this.CollateralTotal)
            }
        }
    };
});
