/*global define */
/*global _:false */

define([
    'scalejs.sandbox!main',
], function (
    sandbox
) {
    'use strict';
    /*jshint camelcase: false */
    return function () {
        var observable = sandbox.mvvm.observable,
            observableArray = sandbox.mvvm.observableArray,
            computed = sandbox.mvvm.computed,
            raise = sandbox.state.raise,
            availableDates = observableArray([]),
            selectedFund = observable(),
            message = observable(),
            region = observable(),
            header = observable(),
            funds = observableArray([]),
            valueDate = observable(),
            selecting = sandbox.mvvm.observable(''),
            display_options = [
                {
                    name: 'table',
                    class: 'th-list'
                },
                {
                    name: 'tile',
                    class: 'th-large'
                },
                {
                    name: 'treemap',
                    class: 'th'
                }
            ],
            action_options = [
                {
                    name: 'table',
                    class: 'th-list'
                },
            ],
            
            display = sandbox.mvvm.observable(display_options[0]),
            actions = sandbox.mvvm.observable(action_options[0]);


        sandbox.query('/CollateralMgmtDates', function (error, data) {
            if (error) {
                console.error(error);
                return;
            }
            availableDates(_.chain(data).map(function ( item ) {
                return item.Value_Date.substring(0, 10);
            }).sort().reverse().value());
            valueDate(_.first(availableDates()));
        });

        valueDate.subscribe(function (change) {
            if(selectedFund()) {
                raise('date.changed', {
                    //date: change,
                    fund: selectedFund().FundNameTicker
                });
            }
        });

        display.subscribe(function (change) {
            raise('display.changed');
        });

       
        computed(function () {
            if(valueDate()) {
                sandbox.query('/CollateralMgmtFundCollBalance/' + valueDate(), function (error, data) {
                    if (error) {
                        console.error(error);
                        return;
                    }
                    funds(data);
                    if(selectedFund()) {
                        var selected = _.chain(data).where({FundNameTicker: selectedFund().FundNameTicker}).first().value();
                        if(selected) {
                            selectedFund(selected);
                        } else {
                            selectedFund(_.first(data));
                        }
                    } else {
                        selectedFund(_.first(data));
                    }
                    console.log('raising event:', 'fund.selected');
                    raise('fund.selected', {
                        date: valueDate(),
                        fund: selectedFund().FundNameTicker
                    });
                });
            }
        });

        return {
            availableDates: availableDates,
            selectedFund: selectedFund,
            funds: funds,
            message: message,
            region: region,
            header: header,
            valueDate: valueDate,
            selecting: selecting,
            display_options: display_options,
            display: display,
            action_options: action_options,
            actions: actions
        };
    };
});
