/* global require, fin */
require([
    'scalejs!application/main,message,fund,openfin',
    'styles!app/app'
], function (
    app
) {
    'use strict';

    if (typeof(fin) !== 'undefined') {
        fin.desktop.main(function() {
            app.run();
        });
    } else {
        app.run();
    }
});
