
define([
    'scalejs!core'
], function (
    core
) {
    'use strict';

    try {
        window.global = window;
    }
    catch (e)
    {
        console.log('window.global = window');
    }

    try {
        global.window = global;
    }
    catch (e)
    {
        console.log('global.window = global');
    }

    core.registerExtension({
        global: global
    });

    global.toolkit = {
        filter: {
            object: function ( obj, rules ) {
                var i, j, prop;
                for (i in rules) {
                    if (rules.hasOwnProperty(i)) {
                        for (j in rules[i]) {
                            if (rules[i].hasOwnProperty(j)) {
                                prop = rules[i][j];
                                obj[prop] = global.toolkit.filter[i](obj[prop]);
                            }
                        }
                    }
                }
                return obj;
            },
            bn: function ( amt ) {
                amt = (Number(amt) / 1000000000).toFixed(2);
                if (amt < 0) {
                    amt = '(' + (-amt).toFixed(2) + ')';
                }
                return amt + ' Bn';
            },
            dateToString: function ( date ) {
                if(isFinite(date)) {
                    return date.toISOString().substring(0, 10);
                } else {
                    return 'NULL';
                }
            },
            parseNum: function ( formattedAmt ) {
                var negativeExpression = /^\([\d,\.]*\)/; //matches values in parentheses (negative values)
                var suffixVals = {
                    Bn: 1000000000,
                    Mn: 1000000,
                    Th: 1000
                };
                var i;

                if (formattedAmt.match(negativeExpression)) {
                    formattedAmt = '-' + formattedAmt.replace(/[\(\)]/g,'');    //replace (5) with -5
                }

                for (var suffix in suffixVals) {
                    if(formattedAmt.search(suffix) !== -1) {
                        formattedAmt = formattedAmt.replace(suffix, '').trim();
                        return parseFloat(formattedAmt) * suffixVals[suffix];
                    }
                }

                return formattedAmt;
            },
            percent: function ( amt ) {
                return (amt * 100).toFixed(1) + '%';
            },
            truncate: function ( s ) {
                var maxLength = 12;
                var ellipses = '…';
                if(s.length >= maxLength) {
                    return s.substring(0, maxLength) + ellipses;
                }
                return s;
            }
        }
    }

})
