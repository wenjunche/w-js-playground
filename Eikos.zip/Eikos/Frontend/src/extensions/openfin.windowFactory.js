﻿/*global define, console, setTimeout, $, fin */
/*jshint -W030, camelcase: false, eqnull: true, forin: false */
define([
    'scalejs!core',
    'knockout'
], function (
    core,
    ko
) {
    'use strict';
    
    if (typeof(fin) === 'undefined') {
        core.registerExtension({
            windowFactory: 'Not running in OpenFin'
        });
        return;
    }

    var observable = ko.observable,
        windowFactory = windowFactory || {},
        app,
        snapPixels = 10,
        selectedThemeName,
        wnds = [],
        eventListeners = {};

    fin.desktop.main(function() {
        app = fin.desktop.Application.getCurrent();
        fin.desktop.System.getMonitorInfo(function(mi) { windowFactory.monitorInfo = mi; });
        fin.desktop.System.addEventListener('monitor-info-changed', function (evnt) {
                windowFactory.monitorInfo = evnt;
        });
    });

    function triggerEvent(eventName, args) {
        if (eventListeners[eventName] != null) {
            var eventListener = eventListeners[eventName];

            for (var i = 0; i < eventListener.length; i += 1) {
                eventListener[i].apply(null, args);
            }
        }
    }

    windowFactory.updateSelectedTheme = function (newSelectedThemeName) {
        var oldSelectedThemeName = selectedThemeName;
        var children = windowFactory.getChildren();
        selectedThemeName = newSelectedThemeName;

        for (var i = 0; i < children.length; i += 1) {
            children[i].contentWindow.document.childNodes[0].classList.remove(oldSelectedThemeName);
            children[i].contentWindow.document.childNodes[0].classList.add(selectedThemeName);
        }
    };

    windowFactory.createWindow = function (customConfig, callback, boundsCallback) {
        var config = {
            'name': 'ChildWindow' + wnds.length,
            'defaultWidth': 1600,
            'defaultHeight': 600,
            'minWidth': 250,
            'minHeight': 150,
            'maxWidth': 3840,
            'maxHeight': 3840,
            'autoShow': false,
            'url': 'about:blank',
            'cornerRounding': {
                'width': 5,
                'height': 5
            },
            'frame': false,
            'maximizable': false,
            'resizable': true,
            'fitToElement': undefined,
            'parentWindow': undefined,
            'alwaysAboveParent': false,
            'closeOnLostFocus': false,
            'enableWindowZoom': false
        };
        customConfig = customConfig || {};

        for (var attrname in customConfig) { 
            config[attrname] = customConfig[attrname]; 
        }

        // Remove this configuration to prevent crashing the fin.desktop.Window call. This is added back after the call:
        delete config.parentWindow;

        var curWnd = new fin.desktop.Window(config, function () {
            var window = curWnd.getNativeWindow(),
                body = window.document.getElementsByTagName('body')[0],
                opening_comment = window.document.createComment(' ko render: $data'),
                closing_comment = window.document.createComment(' /ko '),
                title = window.document.createElement('title');

            curWnd._hidden = !config.autoShow;
            title.innerHTML = config.name || '';
            window.document.head.appendChild(title);

            var links = document.querySelectorAll('link[type="text/css"]'),
                styles = document.getElementsByTagName('style'),
                link,
                style;

            // Copy styles to child:
            for (var i = 0; i < styles.length; i += 1) {
                style = window.document.createElement('style');
                style.innerHTML = styles[i].innerHTML;
                style.rel = styles[i].rel;
                style.type = styles[i].type;
                window.document.head.appendChild(style);
            }

            window.document.childNodes[0].className = selectedThemeName;

            if (config.renderable != null) {
                body.appendChild(opening_comment);
                body.appendChild(closing_comment);

                ko.applyBindings(config.renderable, body);
            } else if (config.onRenderable != null) {
                config.onRenderable(body);
            }

            // Handle dragging:
            curWnd.defineDraggableElements(curWnd.defaultDraggableElements());

            // Handle resizing to content:
            if (config.fitToElement != null) {
                curWnd.fitToElement(window.document.querySelector(config.fitToElement));
            }

            curWnd.triggerEvent('setup');

            function onResizeBounds(event) {
                if (event.changeType >= 1) { // && boundsCallback !== undefined) {
                    // Window was resized:
                    //parseGridStyles(invalidate);
                    curWnd.undock();
                    // boundsCallback(window, config);
                }
                if (event.changeType !== 1) { curWnd.triggerEvent('moved', event); }
                if (event.changeType !== 0) { curWnd.triggerEvent('resized', event); }
            }
            function onResize(event) {
                for (var childID in curWnd.children) {
                    curWnd.children[childID].bringToFront();
                    curWnd.children[childID].focus();
                }
                if (boundsCallback !== undefined) {
                    // Window was resized:
                    boundsCallback(window, config);
                }

                curWnd.getBounds(function (bounds) {
                    curWnd.movedSinceDragStart = true;
                    curWnd.onDrag(bounds.left, bounds.top, true);
                });
            }

            this._addEventListener('bounds-changing', onResizeBounds);
            this._addEventListener('bounds-changed', onResizeBounds);
            this._addEventListener('maximized', onResize);
            this._addEventListener('restored', onResize);
            /*this._addEventListener('focused', function (evt) {
                curWnd.fitToElement(curWnd.config.fitToElement);
                for (var i = 0; i < wnds.length; i += 1) {
                    if (wnds[i] !== curWnd && wnds[i].config.parentWindow !== curWnd && wnds[i].config.closeOnLostFocus) {
                        if (wnds[i].config.hideOnClose) {
                            wnds[i].hide();
                        } else {
                            wnds[i].close();
                        }
                    }
                }

                for (var wndID in curWnd.group) {
                    curWnd.group[wndID].bringToFront();
                }
                curWnd.bringToFront();

                for (var childID in curWnd.children) {
                    if (curWnd.children[childID].config.alwaysAboveParent) {
                        curWnd.children[childID].bringToFront();
                        curWnd.children[childID].focus();
                    }
                }
            });*/
            this._addEventListener('closed', function (evt) {
                if (curWnd.config.parentWindow != null) { delete curWnd.config.parentWindow.children[curWnd.id]; }
                wnds = wnds.filter(function(w) { return w.name !== curWnd.name; });
                for (var childID in curWnd.children) {
                    curWnd.children[childID].close();
                }
                if (config.onClosed !== undefined) { config.onClosed(evt); }
                this.triggerEvent('closed', evt);
            });
            this._addEventListener('hidden', function (evt) {
                curWnd._hidden = true;
                for (var childID in curWnd.children) {
                    curWnd.children[childID].hide();
                }
                curWnd.undock();
                if (config.onHidden !== undefined) { config.onHidden(evt); }
                this.triggerEvent('hidden', evt);
            });
            this._addEventListener('shown', function (evt) {
                curWnd._hidden = false;
                curWnd.fitToElement(curWnd.config.fitToElement);
                for (var childID in curWnd.children) {
                    curWnd.children[childID].show();
                    if (curWnd.children[childID].config.alwaysAboveParent && !curWnd.children[childID]._hidden) {
                        curWnd.children[childID].bringToFront();
                        curWnd.children[childID].focus();
                    }
                }
                if (config.onShown !== undefined) { config.onShown(evt); }
                this.triggerEvent('shown', evt);
            });
 
            if (callback !== undefined) { callback.apply(this, arguments); }

            curWnd._onready = true;
            curWnd.triggerEvent('ready');
        }, function (err) {
            console.log('this was the err', err);
        });

        config.parentWindow = customConfig.parentWindow;
        curWnd._onready = false;
        curWnd.config = config;
        windowFactory.registerWindow(curWnd);

        return curWnd;
    };

    windowFactory.registerWindow = function (curWnd) {
        curWnd.config = curWnd.config || {};
        //curWnd.config = curWnd.config || { name: curWnd.name };
        curWnd._eventListeners = {};
        curWnd.id = wnds.length;
        wnds.push(curWnd); // Add window to internal list (saves time from querying OpenFin)
            
        // Get visible state
        curWnd.isShowing(function (isShowing) {
            curWnd._hidden = !isShowing;
        });

        var xStart,
            yStart,
            startPos = {},            
            mouseDown = false;

        curWnd.movedSinceDragStart = false;
        curWnd.dragTargets = [];

        // Create empty objects to act as lookup tables for grouped windows:
        curWnd.group = Object.create(null);
        curWnd.group[curWnd.id] = curWnd;
        curWnd.children = Object.create(null);

        curWnd.isDocked = observable(false);
        curWnd.isSnappedToEdge = false;

        curWnd.move = function (left, top) {
            // Move window:
            //curWnd.moveTo(left, top); // Not needed, as group now contains the window.

            // Get delta value:
            var curWindow = curWnd.contentWindow,
                leftDelta = left - startPos[curWnd.id].left,
                topDelta = top - startPos[curWnd.id].top,
                group = curWnd.group,
                children = curWnd.children;

            //console.log(leftDelta, topDelta, '-', left, top, '-', curWindow.screenLeft, curWindow.screenTop);

            // Move group:
            for (var id in group) {
                group[id].moveTo(startPos[id].left + leftDelta, startPos[id].top + topDelta);
            }
            // Move children:
            for (id in children) {
                children[id].moveTo(startPos[id].left + leftDelta, startPos[id].top + topDelta);
            }
        };

        curWnd.onDrag = function (left, top, addWindows) {
            var newPos = {
                xDistance: snapPixels,
                yDistance: snapPixels,
                xWindow: undefined,
                yWindow: undefined,
                left: left,
                top: top
            },
                curWindow = curWnd.contentWindow,
                curGroup = curWnd.group,
                otherWnd,
                otherWindow, 
                x, 
                y,
                vertSnap,
                horizSnap;

            x = left + xStart;
            y = top + yStart;

            var monitorRect = windowFactory.monitorInfo.primaryMonitor.availableRect;
            vertSnap = curWnd.hasOwnProperty('vertSnap') ? curWnd.vertSnap : 0;
            horizSnap =  curWnd.hasOwnProperty('horizSnap') ? curWnd.horizSnap : 0;

            if ((x <= horizSnap || y <= vertSnap || 
                 x >= monitorRect.right - horizSnap || 
                 y >= monitorRect.bottom - vertSnap) && ! curWnd.isSnappedToEdge) {
                curWnd.isSnappedToEdge = true;
                curWnd.triggerEvent('snap-to-edge', [{wndw: curWnd, x: x, y: y}]);
            } else if (curWnd.isSnappedToEdge && x > horizSnap && y > vertSnap && 
                       x < monitorRect.right - horizSnap && y < monitorRect.bottom - vertSnap) {
                curWnd.isSnappedToEdge = false;
                curWnd.triggerEvent('unsnap-from-edge', [{wndw: curWnd, x: x, y: y}]);
            }

            for (var i = 0; i < wnds.length; i += 1) {
                otherWnd = wnds[i];
                otherWindow = otherWnd.contentWindow;
                if (otherWindow != null && !otherWnd._hidden && otherWnd.id !== curWnd.id && curGroup[otherWnd.id] === undefined) {
                    // TODO: Optimize the following checks!!!
                    // Handle x-snap:
                    if (Math.abs(left - (otherWindow.screenLeft + otherWindow.outerWidth)) <= newPos.xDistance &&
                        otherWindow.screenTop - top <= curWindow.outerHeight && top <= otherWindow.screenTop + otherWindow.outerHeight) {
                        // right x-snap:
                        newPos.left = (otherWindow.screenLeft + otherWindow.outerWidth);
                        newPos.xDistance = Math.abs(newPos.left - left);
                        newPos.xWindow === undefined ? newPos.xWindow = otherWnd : '';

                        // Handle y-subsnap:
                        if (Math.abs(top - otherWindow.screenTop) <= newPos.yDistance) {
                            newPos.top = otherWindow.screenTop;
                            newPos.yDistance = Math.abs(newPos.top - top);
                            newPos.yWindow = otherWnd;
                        } else if (Math.abs((top + curWindow.outerHeight) - (otherWindow.screenTop + otherWindow.outerHeight)) <= newPos.yDistance) {
                            newPos.top = (otherWindow.screenTop + otherWindow.outerHeight) - curWindow.outerHeight;
                            newPos.yDistance = Math.abs(newPos.top - top);
                            newPos.yWindow = otherWnd;
                        }
                    } else if (Math.abs((left + curWindow.outerWidth) - otherWindow.screenLeft) <= newPos.xDistance &&
                        otherWindow.screenTop - top <= curWindow.outerHeight && top <= otherWindow.screenTop + otherWindow.outerHeight) {
                        // left x-snap:
                        newPos.left = otherWindow.screenLeft - curWindow.outerWidth;
                        newPos.xDistance = Math.abs(newPos.left - left);
                        newPos.xWindow = otherWnd;

                        // Handle y-subsnap:
                        if (Math.abs(top - otherWindow.screenTop) <= newPos.yDistance) {
                            newPos.top = otherWindow.screenTop;
                            newPos.yDistance = Math.abs(newPos.top - top);
                            newPos.yWindow = otherWnd;
                        } else if (Math.abs((top + curWindow.outerHeight) - (otherWindow.screenTop + otherWindow.outerHeight)) <= newPos.yDistance) {
                            newPos.top = (otherWindow.screenTop + otherWindow.outerHeight) - curWindow.outerHeight;
                            newPos.yDistance = Math.abs(newPos.top - top);
                            newPos.yWindow = otherWnd;
                        }
                    }
                        // Handle y-snap:
                    else if (Math.abs(top - (otherWindow.screenTop + otherWindow.outerHeight)) <= newPos.yDistance &&
                        otherWindow.screenLeft - left <= curWindow.outerWidth && left <= otherWindow.screenLeft + otherWindow.outerWidth) {
                        // top y-snap:
                        newPos.top = (otherWindow.screenTop + otherWindow.outerHeight);
                        newPos.yDistance = Math.abs(newPos.top - top);
                        newPos.yWindow = otherWnd;

                        // Handle x-subsnap:
                        if (Math.abs(left - otherWindow.screenLeft) <= newPos.xDistance) {
                            newPos.left = otherWindow.screenLeft;
                            newPos.xDistance = Math.abs(newPos.left - left);
                            newPos.xWindow === undefined ? newPos.xWindow = otherWnd : '';
                        } else if (Math.abs((left + curWindow.outerWidth) - (otherWindow.screenLeft + otherWindow.outerWidth)) <= newPos.xDistance) {
                            newPos.left = (otherWindow.screenLeft + otherWindow.outerWidth) - curWindow.outerWidth;
                            newPos.xDistance = Math.abs(newPos.left - left);
                            newPos.xWindow === undefined ? newPos.xWindow = otherWnd : '';
                        }
                    } else if (Math.abs((top + curWindow.outerHeight) - otherWindow.screenTop) <= newPos.yDistance &&
                        otherWindow.screenLeft - left <= curWindow.outerWidth && left <= otherWindow.screenLeft + otherWindow.outerWidth) {
                        // bottom y-snap:
                        newPos.top = otherWindow.screenTop - curWindow.outerHeight;
                        newPos.yDistance = Math.abs(newPos.top - top);
                        newPos.yWindow = otherWnd;

                        // Handle x-subsnap:
                        if (Math.abs(left - otherWindow.screenLeft) <= newPos.xDistance) {
                            newPos.left = otherWindow.screenLeft;
                            newPos.xDistance = Math.abs(newPos.left - left);
                            newPos.xWindow === undefined ? newPos.xWindow = otherWnd : '';
                        } else if (Math.abs((left + curWindow.outerWidth) - (otherWindow.screenLeft + otherWindow.outerWidth)) <= newPos.xDistance) {
                            newPos.left = (otherWindow.screenLeft + otherWindow.outerWidth) - curWindow.outerWidth;
                            newPos.xDistance = Math.abs(newPos.left - left);
                            newPos.xWindow === undefined ? newPos.xWindow = otherWnd : '';
                        }
                    }
                }
            }

            // Move window:
            if (newPos.left !== curWindow.screenLeft || newPos.top !== curWindow.screenTop) {
                curWnd.movedSinceDragStart = true;
                curWnd.move(newPos.left, newPos.top);
            }

            // Add any new grouped windows:
            if (addWindows && (newPos.xWindow !== undefined || newPos.yWindow !== undefined) && curWnd.movedSinceDragStart) {
                if (newPos.xWindow !== undefined) {
                    curWnd.dock(newPos.xWindow);
                }
                if (newPos.yWindow !== undefined) {
                    curWnd.dock(newPos.yWindow);
                }
            }
        };

        curWnd.dock = function (otherWnd) {
            // Merge groups:
            var otherGroup = otherWnd.group,
                wnd;

            for (var id in otherGroup) {
                wnd = otherGroup[id];
                curWnd.group[id] = wnd; // Add other group to curGroup.
                wnd.group = curWnd.group; // Make sure all windows reference the same group object!
                wnd.isDocked(true);
            }

            curWnd.isDocked(true);
        };

        curWnd.undock = function () {
            var curGroup = curWnd.group,
                wnd;

            for (var id in curGroup) {
                    // Reset each window's group:
                wnd = curGroup[id];
                wnd.group = Object.create(null);
                wnd.group[id] = wnd;
                wnd.isDocked(false);
            }
        };

        /*var originalClose = curWnd.close;
        curWnd.close = function (force, callback, errorCallback) {

            originalClose(force, callback, errorCallback);
        }*/

        curWnd.closeChildren = function () {
            for (var childID in curWnd.children) {
                curWnd.children[childID].close();
                delete curWnd.children[childID];
            }
        };

        curWnd.fitToElement = function (element) {
            if (element != null) {
                curWnd.resizeTo(element.offsetWidth, element.offsetHeight, 'top-left');
            }
        };

        curWnd._addEventListener = curWnd.addEventListener;
        curWnd.addEventListener = function (eventName, eventCallback) {
            if (curWnd._eventListeners[eventName] == null) { curWnd._eventListeners[eventName] = []; }

            curWnd._eventListeners[eventName].push(eventCallback);
        };

        curWnd._removeEventListener = curWnd.removeEventListener;
        curWnd.removeEventListener = function (eventName, eventCallback) {
            var eventListener = curWnd._eventListeners[eventName] || [];

            for (var i = eventListener.length - 1; i >= 0; i -= 1) {
                if (eventListener[i] === eventCallback) { eventListener.splice(i, 1); }
            }
        };

        curWnd.triggerEvent = function (eventName, args) {
            if (curWnd._eventListeners[eventName] != null) {
                var eventListener = curWnd._eventListeners[eventName];

                for (var i = 0; i < eventListener.length; i += 1) {
                    eventListener[i].apply(curWnd, args);
                }
            }
        };

        curWnd.onDOMReady = function (eventCallback) {
            if (curWnd.contentWindow == null) {
                // Alternative if window isn't setup yet:
                var interval = setInterval(function () {
                    if (curWnd.contentWindow != null) {
                        if (curWnd.contentWindow.document.readyState !== 'complete') {
                            curWnd.contentWindow.addEventListener('onload', eventCallback, false);
                        } else {
                            eventCallback();
                        }
                        clearInterval(interval);
                    }
                }, 5);
            } else if (curWnd.contentWindow.document.readyState !== 'complete') {
                curWnd.contentWindow.addEventListener('onload', eventCallback, false);
            } else {
                eventCallback();
            }
        };

        curWnd.onReady = function (eventCallback) {
            if (curWnd._onready) {
                eventCallback();
            } else {
                curWnd.addEventListener('ready', eventCallback);
            }
        };

        curWnd.setZoom = function (percent) {
            curWnd.contentWindow.document.body.style.zoom = percent;
            curWnd.triggerEvent('zoom');
        };
        curWnd.getZoom = function () {
            if (curWnd.contentWindow.document.body.style.zoom === '') { curWnd.contentWindow.document.body.style.zoom = 1; }
            return curWnd.contentWindow.document.body.style.zoom;
        };
        curWnd.zoomIn = function () {
            if (curWnd.contentWindow.document.body.style.zoom === '') { curWnd.contentWindow.document.body.style.zoom = 1; }
            curWnd.contentWindow.document.body.style.zoom *= 1.1;
            curWnd.triggerEvent('zoom');
        };
        curWnd.zoomOut = function () {
            if (curWnd.contentWindow.document.body.style.zoom === '') { curWnd.contentWindow.document.body.style.zoom = 1; }
            curWnd.contentWindow.document.body.style.zoom /= 1.1;
            curWnd.triggerEvent('zoom');
        };

        curWnd.getBoundingBox = function () {
            var window = curWnd.contentWindow;
            return {
                left: window.screenLeft,
                top: window.screenTop,
                right: window.screenLeft + window.outerWidth,
                bottom: window.screenTop + window.outerHeight,
            };
        };
        curWnd.moveToCenter = function (posx, posy, onMove) {
            fin.desktop.System.getMonitorInfo(function (monitorInfo) {
                var monitor = windowFactory.determineMonitor(posx, posy, monitorInfo) || monitorInfo.primaryMonitor,
                    width = curWnd.contentWindow.outerWidth,
                    height = curWnd.contentWindow.outerHeight;

                posx = (monitor.availableRect.right - monitor.availableRect.left - width) / 2 + monitor.availableRect.left;
                posy = (monitor.availableRect.bottom - monitor.availableRect.top - height) / 2 + monitor.availableRect.top;

                // MoveTo
                curWnd.moveTo(posx, posy, onMove);
            }, function (reason) {
                console.error('Unable to get monitor information. Error: ' + reason);
            });
        };
        curWnd.moveToOrCenter = function (posx, posy, onMove) {
            fin.desktop.System.getMonitorInfo(function (monitorInfo) {
                var monitor = windowFactory.determineMonitor(posx, posy, monitorInfo) || monitorInfo.primaryMonitor,
                    width = curWnd.contentWindow.outerWidth,
                    height = curWnd.contentWindow.outerHeight;

                if (monitor.availableRect.left >= posx || 
                    monitor.availableRect.right <= posx + width || 
                    monitor.availableRect.top >= posy || 
                    monitor.availableRect.bottom <= posy + height) {
                    // Center
                    posx = (monitor.availableRect.right - monitor.availableRect.left - width) / 2 + monitor.availableRect.left;
                    posy = (monitor.availableRect.bottom - monitor.availableRect.top - height) / 2 + monitor.availableRect.top;
                }
                // MoveTo
                curWnd.moveTo(posx, posy, onMove);
            }, function (reason) {
                console.error('Unable to get monitor information. Error: ' + reason);
            });
        };
        curWnd.moveToCenterOrBelow = function (posx, posy, otherWnd, onMove) {
            fin.desktop.System.getMonitorInfo(function (monitorInfo) {
                var monitor = windowFactory.determineMonitor(posx, posy, monitorInfo) || monitorInfo.primaryMonitor,
                    width = curWnd.contentWindow.outerWidth,
                    height = curWnd.contentWindow.outerHeight;

                // We floor the position to make sure they are integer values, 
                // since all positions we retrieve are integer values (so we can compare against them)
                posx = Math.floor((monitor.availableRect.right - monitor.availableRect.left - width) / 2 + monitor.availableRect.left);
                posy = Math.floor((monitor.availableRect.bottom - monitor.availableRect.top - height) / 2 + monitor.availableRect.top);

                if (otherWnd != null) {
                    var otherBox = otherWnd.getBoundingBox();

                    if (otherBox != null && otherBox.left === posx && otherBox.top === posy) {
                        posy = otherBox.bottom;
                    }
                }

                // MoveTo
                curWnd.moveTo(posx, posy, onMove);
            }, function (reason) {
                console.error('Unable to get monitor information. Error: ' + reason);
            });
        };

        //Sets the height and width of the window up to the bounds of the monitor, eventCallback will be called when complete (optional)
        curWnd.resizeToOrMax = function (proposedWidth, proposedHeight, eventCallback) {
            fin.desktop.System.getMonitorInfo(function (monitorInfo) {
                //Get constraints
                var position = curWnd.getBoundingBox();
                var available = (windowFactory.determineMonitor(position.left, position.top, monitorInfo) || monitorInfo.primaryMonitor).availableRect;

                //determine max dimenions
                var maxW = position.left + proposedWidth < available.right ? proposedWidth : available.right - position.left;
                var maxH = position.top + proposedHeight < available.bottom ? proposedHeight : available.bottom - position.top;

                // Resize
                curWnd.resizeTo(maxW, maxH, 'top-left', eventCallback);
            }, function (reason) {
                console.error('Unable to get monitor information. Error: ' + reason);
            });
        };

        curWnd._addEventListener('focused', function (evt) {
            curWnd.fitToElement(curWnd.config.fitToElement);
            for (var i = 0; i < wnds.length; i += 1) {
                if (wnds[i] !== curWnd && wnds[i].config.parentWindow !== curWnd && wnds[i].config.closeOnLostFocus) {
                    if (wnds[i].config.hideOnClose) {
                        wnds[i].hide();
                    } else {
                        wnds[i].close();
                    }
                }
            }

            for (var wndID in curWnd.group) {
                curWnd.group[wndID].bringToFront();
            }
            curWnd.bringToFront();

            for (var childID in curWnd.children) {
                curWnd.children[childID].bringToFront();
                curWnd.children[childID].focus();
            }

            curWnd.triggerEvent('focused', [evt]);
        });

        curWnd._addEventListener('bounds-changed', function (evt) {
            curWnd.triggerEvent('bounds-changed', [evt]);
        });

        curWnd.defineDraggableElements = function (targets) {
            if (typeof targets === 'string') { targets = curWnd.contentWindow.document.querySelectorAll(targets); }

            var mouseDownHandler =  function (event) {
                mouseDown = true;
                xStart = event.x;
                yStart = event.y;
                curWnd.movedSinceDragStart = false;
                for (var wndID in curWnd.group) {
                    startPos[wndID] = {
                        left: curWnd.group[wndID].contentWindow.screenLeft,
                        top: curWnd.group[wndID].contentWindow.screenTop
                    };
                }
                for (wndID in curWnd.children) {
                    startPos[wndID] = {
                        left: curWnd.children[wndID].contentWindow.screenLeft,
                        top: curWnd.children[wndID].contentWindow.screenTop
                    };
                }
                return;
            };

            for (var i = 0; i < targets.length; i += 1) {
                targets[i].addEventListener('mousedown', mouseDownHandler);
            }
        };

        curWnd.defaultDraggableElements = function () {
            return curWnd.contentWindow.document.querySelectorAll('.ui-draggable');
        };

        // Add to parent window if parent exists:
        if (curWnd.config.parentWindow != null) {
            curWnd.config.parentWindow.children[curWnd.id] = curWnd;
        }



        // Add window listeners:
        curWnd.onDOMReady(function () {
            curWnd.contentWindow.document.childNodes[0].className = selectedThemeName;

            curWnd.contentWindow.addEventListener('mousemove', function (event) {
                if (mouseDown) {
                    fin.desktop.System.getMousePosition(function (evt) {
                        var x = parseInt(evt.left),
                            y = parseInt(evt.top);

                        //console.log('X: ' + x + '; Y: ' + y + '; xStart: ' + xStart + '; yStart: ' + yStart);

                        curWnd.onDrag(x - xStart, y - yStart, false);
                    });
                }
            });

            curWnd.contentWindow.addEventListener('mouseup', function (event) {
                if (mouseDown) {
                    mouseDown = false;
                    fin.desktop.System.getMousePosition(function (evt) {
                        var x = parseInt(evt.left),
                            y = parseInt(evt.top);

                        curWnd.onDrag(x - xStart, y - yStart, true);
                    });
                }
            });

            if (curWnd.config.enableWindowZoom) {
                curWnd.contentWindow.document.body.style.zoom = 1;
                curWnd.contentWindow.addEventListener('wheel', function (evt) {
                    if (evt.ctrlKey) {
                        if (evt.wheelDeltaY > 0) {
                            // scroll up + ctrl
                            curWnd.zoomIn();
                        } else if (evt.wheelDeltaY < 0) {
                            // scroll down + ctrl
                            curWnd.zoomOut();
                        }
                    }
                });
            }
        });

        triggerEvent('added', [curWnd]);
    };

    windowFactory.getChildren = function () {
        var children = [],
            childrenIDs = Object.keys(wnds);

        for (var i = 0; i < childrenIDs.length; i += 1) {
            children.push(wnds[childrenIDs[i]]);
        }

        return children;
    };

    windowFactory.addEventListener = function (eventName, eventCallback) {
        if (eventListeners[eventName] == null) { eventListeners[eventName] = []; }

        eventListeners[eventName].push(eventCallback);
    };

    windowFactory.removeEventListener = function (eventName, eventCallback) {
        var eventListener = eventListeners[eventName] || [];

        for (var i = eventListener.length - 1; i >= 0; i -= 1) {
            if (eventListener[i] === eventCallback) { eventListener.splice(i, 1); }
        }
    };

    windowFactory.getOwnerWindow = function (element) {
        var elWindow = element.ownerDocument.defaultView;

        for (var wndID in wnds) {
            if (elWindow === wnds[wndID].contentWindow) { return wnds[wndID]; }
        }
    };

    windowFactory.getWindow = function (name) {
        for (var i = 0; i < wnds.length; i += 1) {
            if (name === wnds[i].name) { return wnds[i]; } 
        }
    };

    windowFactory.determineMonitor = function (posx, posy, monitorInfo) {
        var monitors = monitorInfo.nonPrimaryMonitors;
        monitors.push(monitorInfo.primaryMonitor);
        for (var i = 0; i < monitors.length; i += 1) {
            if (posx >= monitors[i].monitorRect.left && posx <= monitors[i].monitorRect.right && 
                    posy >= monitors[i].monitorRect.top && posy <= monitors[i].monitorRect.bottom) {
                return monitors[i];
            }
        }
    };

    // register function to backend
    core.registerExtension({
        windowFactory: windowFactory
    });

});
