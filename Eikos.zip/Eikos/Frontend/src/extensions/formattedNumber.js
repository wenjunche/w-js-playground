/*global define*/
/*jsling sloppy: true*/
define([
    'scalejs!core',
    'knockout'
], function (
    core,
    ko
) {

    'use strict';

    ko.extenders.formattedNumber = function (target) {
        var result = ko.computed({
            read: function () {
                if (target() === null || target() === '') {
                    return '0';
                } else {
                    return addDelimiters(target().toString());
                }
            },

            write: function (newValue) {
                if (newValue === null || newValue === '')
                {
                    target('');
                    return;
                }
                var valueToWrite = removeDelimiters(newValue.toString());
                if (!isNaN(valueToWrite) && newValue !== target()) {
                    target(valueToWrite);
                }
            }
        });

        return result;
    };

    function negativeToParentheses(nStr) {
        if(nStr.charAt(0) === '-') {
            return '(' + nStr.substring(1) + ')';
        } else {
            return nStr;
        }
    }

    function addDelimiters(nStr) {
        var negativeExpression = /^\([\d,\.]*\)/;
        nStr += '';
        // sometimes nStr has a negative value with parantheses
        // change it back to - format so this function works correctly
        if (nStr.match(negativeExpression)) {
            nStr = '-' + nStr.replace(/[\(\)]/g,'');    //replace (5) with -5
        }
        nStr = nStr.replace(/[^\d.-]/g, '');    //remove delimiters but dont convert to Number
        var dpos = nStr.indexOf('.');
        var nStrEnd = '';
        if (dpos !== -1) {
            nStrEnd = '.' + nStr.substring(dpos + 1, nStr.length);
            nStr = nStr.substring(0, dpos);
        }
        var rgx = /(\d+)(\d{3})/;
        while (rgx.test(nStr)) {
            nStr = nStr.replace(rgx, '$1,$2');
        }
        return negativeToParentheses(nStr + nStrEnd);
    }

    function removeDelimiters(nStr) {
        var negativeExpression = /^\([\d,\.]*\)/;
        if (typeof nStr == 'string' || nStr instanceof String) {
            if (nStr.match(negativeExpression)) {
                nStr = '-' + nStr.replace(/[\(\)]/g,'');    //replace (5) with -5
            }
            return Number(nStr.replace(/[^\d.-]/g, ''));
        } else {
            return nStr;
        }
    }

    function removeDecimal(val) {
        if(typeof val === 'number') {
            return val.toFixed(0);
        } else {
            return val;
        }
    }

    //make addDelimiter function available to sandbox because it is useful
    core.registerExtension({
        formattedNumber: {
            addDelimiters: addDelimiters,
            removeDelimiters: removeDelimiters,
            removeDecimal: removeDecimal
        }
    });

});
