
/*global define*/
/*jsling sloppy: true*/
define([
    'scalejs!core',
    'knockout',
    'hammer'
], function (
    core,
    ko,
    Hammer
) {

    'use strict';

    ['Tap', 'Pan', 'Swipe', 'Pinch', 'Rotate', 'Press']
    .forEach(function ( gesture ) {
        var lower;

        lower = gesture.toLowerCase();

        ko.bindingHandlers['hm' + lower] = {
            init: function ( element, valueAccessor, allBindingsAccessor, data ) {
                var settings;

                if (!(settings = valueAccessor())) {
                    return;
                }

                if (!settings.handler) {
                    settings = { handler: settings }
                }

                settings.event = lower;

                if (!element._hammer) {
                    element._hammer = new Hammer.Manager(element,
                        allBindingsAccessor().hmoptions || { });
                }

                element._hammer.add(new Hammer[gesture](settings));
                element._hammer.on(settings.event, function ( ) {
                    console.debug('hammer: ' + lower + ':'  + element);
                    settings.handler.apply(data, arguments);
                });

            }
        };
    });
});
