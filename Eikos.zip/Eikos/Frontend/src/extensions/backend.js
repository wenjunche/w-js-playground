/*global define*/
/*jsling sloppy: true*/

define([
    'scalejs!core',
    'underscore'
], function (
    core,
    _
) {

    'use strict';

    var service = 'https://mobile.eikospartners.com';

    if (window.service !== null) {
        service = window.service;
    }

    /*jshint camelcase: false */
    var service_url = service;

    /**
     * process data into usable js object and run callback
     * @param {Object} Object       Object with data to be processed
     * @param {Function} callback   callback function
     */
    function process ( data, callback ) {

        try {
            if(data && data.length > 0) {
              data = JSON.parse(data);
            }
        } catch (e) {
            return callback(e);
        }

        callback(null, data);
    }//;

    /**
     * Open connection to backend and post
     * @param {Object} Object       Object with data to be posted
     * @param {Function} callback   callback function
     */
    function ajax ( verb, path, params, callback ) {
        var r = new XMLHttpRequest();
        r.onreadystatechange = function () {
            if (r.readyState !== 4) {
                return;
            }
            if (r.status !== 200) {
                return callback('request failed with status ' + r.status);
            }
            process(r.responseText, callback);
        };

        var abort = r.abort.bind(r);
        r.abort = function () {
            callback(null, [ ]);
            abort();
        };
        r.open(verb, service_url + path, true);
        //r.setRequestHeader('Content-Type', 'application/json');
        if(params) {
            r.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            r.setRequestHeader('Content-length', params.length);
            r.setRequestHeader('Connection', 'close');
            r.send(params);
        } else {
            r.send();
        }
        return r;
    }//;


    /**
     * Post request to backend interface
     * @param {Object} options          database connection options
     * @param {String} options.group    name of group to access
     * @param {String} options.menu     name of menu to access
     * @param {Array}  [options.params] extra parameters to send
     * @param {Function} callback       function to callback with data
     * @param {Object}  callback.err    error object from callback
     * @param {Object}  callback.data   data object from callback
     */
    function query ( path, callback ) {
        callback = _.once(callback); // TODO: find a way to set timeout
        return ajax('GET', path, null, callback);
    }//;

    /**
     * Post request to backend interface
     * @param {Object} options          database connection options
     * @param {String} options.group    name of group to access
     * @param {String} options.menu     name of menu to access
     * @param {Array}  [options.params] extra parameters to send
     * @param {Function} callback       function to callback with data
     * @param {Object}  callback.err    error object from callback
     * @param {Object}  callback.data   data object from callback
     */
    function post ( path, callback ) {
        callback = _.once(callback); // TODO: find a way to set timeout
        return ajax('POST', path, null, callback);
    }//;

    function postForm (path, params, callback) {
        callback = _.once(callback); // TODO: find a way to set timeout
        return ajax('POST', path, params, callback);
    }

    // register function to backend
    core.registerExtension({
        query: query,
        post: post,
        postForm: postForm
    });

});
