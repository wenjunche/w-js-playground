define([
    'scalejs!application/main,message,fund,openfin',
    'scalejs!core',
    'chai'
],
function(app, core, chai) {
    /* global describe, it, expect */
    'use strict';
    var expect = chai.expect;
    describe('stateChart test', function () {


        it('stateChart starts in fund.waiting', function (done) {
            var stateObservable = core.state.observe();
            var stateHistory = [];
            stateObservable.subscribe(function(state) {
                if (state.event === 'entry') {
                    stateHistory.push(state.state);
                }
                console.log('state change observable ');
                console.log(state);
                console.log(stateHistory);
            });
            core.onApplicationEvent(function(e) {
                console.log('application event');
                console.log(e);                               
                if (e === 'started') {
                    expect(stateHistory.slice(0,7).join() === 'scalejs-app,root,app,message,main,fund,fund.waiting' );
                    done();
                }
            });
            app.run();
            /*var state = {};
            state.arr = undefined;
            state.arr = state.arr || [];
            state.arr.forEach(function(e) { console.log(e) });
            done();
            */
        });
    });

});
