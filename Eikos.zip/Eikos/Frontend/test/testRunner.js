'use strict';
/*jshint camelcase: false */
/* jshint -W024 */
/* jshint expr:true */
/* global mochaPhantomJS */

//Configure RequireJS
require.config({
    baseUrl: '../src',
    config: {
      'scalejs.mvvm': {
          doNotRender: true
      }
    },
    paths: {
      'test' : '../test',
      'scalejs.sandbox': '../bower_components/scalejs/dist/scalejs.min'
    },
    shim: {
        'mocha': {
            init: function() {
                this.mocha.setup('bdd');
                return this.mocha;
            }
        }
    }
});

// Require libraries
require([
    'require',
    'chai',
    'mocha'
], function (require, chai, mocha) {

    // Chai
    var assert = chai.assert;
    var should = chai.should();
    var expect = chai.expect;

    // Require base tests before starting
    require(['../test/fundViewModel.test','../test/stateChartTest'], function (person) {
        mocha.setup({ globals: ['hasCert'] });

        // Start runner
        if (window.mochaPhantomJS) {
            mochaPhantomJS.run();
        }
        else { mocha.run(); }
    });

});


