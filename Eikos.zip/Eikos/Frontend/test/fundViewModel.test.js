define([
    'scalejs.sandbox!fundViewModel.test',
    'app/fund/viewmodels/fundViewModel',
    'chai',
    'scalejs!core',
    'scalejs!application',
    'scalejs.reactive'
], function (
    sandbox,
    fundViewModel,
    chai,
    core
) {
    'use strict';
    /*jshint camelcase: false */

    var rxObservable = core.reactive.Observable,
        expect = chai.expect,
        observable = sandbox.mvvm.observable;

    describe('authentication test', function () {
        it('is able to login', function (done) {
            sandbox.postForm('/api/login/', 'user=peter&pass=temp1234', function (error, data) {
                console.log('error: ', error);
                console.log(data);
                done();
            });
        });
    });

    describe('fundViewModel test', function () {


        it('VM exists', function (done) {

            var vm = fundViewModel(
                {
                    'FundName':'EIKOS GLOBAL MACRO FUND',
                    'FundNameTicker':'EGMF',
                    'CollateralTotal':150123456,
                    'FundOrder':1,
                    'Icon':'globe'
                },
                observable('2015-04-01'),
                {
                    name: 'table',
                    class: 'th-list'
                }
            );
            expect(vm).not.equal(undefined);
            done();
        });

        /*

        it('VM gets data', function (done) {

            var vm = fundViewModel(
                {
                    'FundName':'EIKOS GLOBAL MACRO FUND',
                    'FundNameTicker':'EGMF',
                    'CollateralTotal':150123456,
                    'FundOrder':1,
                    'Icon':'globe'
                },
                observable('2015-04-01'),
                {
                    name: 'table',
                    class: 'th-list'
                }
            );
            expect(vm).to.have.property('cpSummary');
            expect(vm.cpSummary).to.have.property('data');
            vm.cpSummary.data.subscribe(function (data) {
                expect(data).to.have.length.above(0);
                done();
            });
        });
        */

    });
});
