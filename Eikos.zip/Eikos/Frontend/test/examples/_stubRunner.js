
// Configure RequireJS
require.config({
    baseUrl: '' /*,
    urlArgs: "v=" + (new Date()).getTime()*/
});

// Require libraries
require([
    'require',
    '../bower_components/chai/chai',
    '../bower_components/mocha/mocha'
], function (require, chai) {

    // Chai
    assert = chai.assert;
    should = chai.should();
    expect = chai.expect;

    // Mocha
    mocha.setup('bdd');


    // Require base tests before starting
    require(['_stub_stringCalculator.test'], function (person) {
        mocha.setup({ globals: ['hasCert'] });
        // Start runner
        if (window.mochaPhantomJS) {
            mochaPhantomJS.run();
        }
        else { mocha.run(); }
    });

});
