define(['_stub_stringCalculator'], function () {

    describe('_stub_stringCalculator', function () {

        describe('when an empty string is passed in', function () {
            it('returns 0', function () {
                var result = _stub_stringCalculator.add('');
                assert(result === 0);
            });
        });

        describe('when a number is passed in', function () {
            it('returns the number', function () {
                var result = _stub_stringCalculator.add('2');
                assert(result === 2);
            });
        });

        describe('when string is passed in', function () {
            it('returns NaN', function () {
                var result = _stub_stringCalculator.add('a');
                assert(isNaN(result));
            });
        });

        describe('when 1,2 is passed in', function () {
            it('returns 3', function () {
                var result = _stub_stringCalculator.add('1,2');
                assert(result === 3);
            });
        });
    });
});
