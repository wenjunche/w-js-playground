try
{
	var chai = require('chai');
} catch(e)
{
	console.log('no require');
}

// require([
    // 'require',
    // 'chai',
    // 'mocha'
// ], function (require, chai) {


	var expect = chai.expect;
	var should = chai.should();

describe('FE_Test1', function() {
	it('1 should equal 1', function() {
	  expect(1).to.equal(1);
	});
});

describe('FE_Test2', function() {
	it('2 should be greater than 1', function() {
	  expect(2).to.be.above(1);
	});
});

	function iseven(num) {
	  if (num%2 !== 0) return false;
	  return true;
	}

describe('FE_Test3', function() {
	it('should always return a boolean', function() {
	  expect(iseven(2)).to.be.a('boolean');
	});
});

describe('FE_Test4', function() {
	it('calling iseven(76) sould return true.', function() {
	  expect(iseven(76)).to.be.true;
	});
});

describe('FE_Test5', function() {
	it('calling iseven(77) sould return false.', function() {
	  expect(iseven(77)).to.be.false;
	});
});

describe('FE_TestAsync', function() {
	it('2 should be greater than 1', function(done) {
		require([ ], function() {
			expect(2).to.be.above(1);
			done();
		});
	});
});

//});
 // }
 // );
