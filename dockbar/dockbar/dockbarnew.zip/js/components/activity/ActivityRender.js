React.render(<div>
                <HeaderComponent caption="Activity" />
                <ActivityComponent componentId="FirstActivityComponent" />                               
            </div>
        , document.getElementById('render')
);