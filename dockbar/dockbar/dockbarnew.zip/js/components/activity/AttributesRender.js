React.render(<div>
                <HeaderComponent caption="Activity Attributes - Daily"/>
                <AttributesComponent componentId="attributesComponent" />                                    
            </div>
        , document.getElementById('render')
);
