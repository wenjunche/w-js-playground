React.render(
    <span>
        <HeaderComponent exit="true" caption="Nucleus Dashboard" exitImageSrc="img/exit.png"/>
        <DockbarMenu />
        <FooterComponent/>
     </span>
    , document.getElementById('render'));