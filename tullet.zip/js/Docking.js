/**
 * Created by haseebriaz on 03/03/15.
 */

window.addEventListener("DOMContentLoaded", function() {

    fin.desktop.main(function () {

        // var dockingManager = new DockingManager();
        var counter = 0;
        // dockingManager.register(fin.desktop.Window.getCurrent(), false);

        fin.desktop.Window.getCurrent().addEventListener("focused", function (event) {
            console.log("The window focused");
        });

        fin.desktop.Window.getCurrent().addEventListener("blurred", function (event) {
            console.log("The window blurred");
        });


        fin.desktop.InterApplicationBus.addSubscribeListener(function (uuid, topic) {
            console.log("The application " + uuid + " has subscribed to " + topic);
        });

        fin.desktop.InterApplicationBus.addUnsubscribeListener(function (uuid, topic) {
            console.log("The application " + uuid + " has unsubscribed to " + topic);
        });

        fin.desktop.System.addEventListener("application-core-terminated", function () {
            console.log("application core terminated");
        });

        fin.desktop.System.addEventListener("application-closed", function (v) {
            console.log(v);
        });

        function createChildWindow() {

            var dw = new fin.desktop.Window({
                name: "child" + counter++,
                url2: "http://openfin.github.io/example-fin-hypergrid-behavior-json/",
                url: "childWindow.html", 
                defaultWidth: 200,
                defaultHeight: 150,
                defaultTop: 100 + (counter * 100),
                defaultLeft: 100 + (counter * 100),
                frame: false,
                resize: false,
                autoShow: true,
                saveWindowState: false,
//                showTaskbarIcon: false,
                transparent: false
                //cornerRounding: { width: 33, height: 33 }
                //accelerator: {
                //        zoom: true,
                //        devtools: true
                //}                
            }, function () {

                // dockingManager.register(dw);
                dw.resizeTo(130, 130);
                dw.updateOptions({"alwaysOnTop":true,"contextMenu":true,"cornerRounding":{"height":130,"width":130},"frame":false,"hideOnClose":false,"maximizable":false,"minimizable":false,"resizable":false});
            });

            // dw.addEventListener("closed", function (event) {
            //    console.log("The window closed");
            //});

            return dw;
        }

        function createApp() {
            var app  = new fin.desktop.Application({name:'abc', 
                                        uuid:'abc', 
                                        url:'http://test.openf.in/bus/publisher.html', 
                                        autoShow:true,
                                        frameConnect: 'main-window'
                                    }, 
                        function() {
                            app.run();
                        });
        }

        function getStates() {
            fin.desktop.Application.getCurrent().getChildWindows(function (windows) {
                async.map(windows, function (window, done) {
                        window.getState(function (state) {
                            done(null, 'name: ' + window.name + ', state: ' + state + '\n');
                        });
                    },
                    function (err, results) {
                        document.getElementById('states').value = '';
                        results.forEach(function (result) {
                            document.getElementById('states').value += result;
                        });
                    });
            });
        }

        function getBounds() {
            fin.desktop.Application.getCurrent().getChildWindows(function (windows) {
                async.map(windows, function (window, done) {
                        window.getBounds(function (bounds) {
                            done(null, 'name: ' + window.name + ', top: ' + bounds.top + ', left: ' + bounds.left + '\n');
                        });
                    },
                    function (err, results) {
                        document.getElementById('bounds').value = '';
                        results.forEach(function (result) {
                            document.getElementById('bounds').value += result;
                        });
                    });
            });
        }

        function bringChildFront() {
            var w = fin.desktop.Window.wrap("OpenFinHelloWorld", "child0");
            w.show();
            w.bringToFront();
            w.focus();
        }


        function updateDimentions(){
            document.getElementById("dimentions").innerHTML = "x: " + window.screenLeft + ", y: " + window.screenTop + ", width: " + window.outerWidth + ", height: "+ window.outerHeight;
        }

        document.getElementById("createWindows").onclick = createChildWindow;
        document.getElementById("createApp").onclick = createApp;
        document.getElementById("getStates").onclick = getStates;
        document.getElementById("bringChild").onclick = bringChildFront;

        document.getElementById("textInput").onfocus = bringChildFront;

        setInterval(updateDimentions, 1000);

        fin.desktop.InterApplicationBus.publish("JsAppReadyForDotNet", {text: "I am here"});

        console.log("DOMContentLoaded");
    });

    document.getElementById("printMe").onclick = printMe;
    function printMe() {
        window.print();
        console.log("after calling print");
    }

    function showNotificationCenter() {
        fin.desktop.System.showChromeNotificationCenter();
    }
    document.getElementById("NotificationCenter").onclick = showNotificationCenter;

    function openPDF() {
        var pdfData =
            'JVBERi0xLjcKCjEgMCBvYmogICUgZW50cnkgcG9pbnQKPDwKICAvVHlwZSAvQ2F0YWxvZwog' +
            'IC9QYWdlcyAyIDAgUgo+PgplbmRvYmoKCjIgMCBvYmoKPDwKICAvVHlwZSAvUGFnZXMKICAv' +
            'TWVkaWFCb3ggWyAwIDAgMjAwIDIwMCBdCiAgL0NvdW50IDEKICAvS2lkcyBbIDMgMCBSIF0K' +
            'Pj4KZW5kb2JqCgozIDAgb2JqCjw8CiAgL1R5cGUgL1BhZ2UKICAvUGFyZW50IDIgMCBSCiAg' +
            'L1Jlc291cmNlcyA8PAogICAgL0ZvbnQgPDwKICAgICAgL0YxIDQgMCBSIAogICAgPj4KICA+' +
            'PgogIC9Db250ZW50cyA1IDAgUgo+PgplbmRvYmoKCjQgMCBvYmoKPDwKICAvVHlwZSAvRm9u' +
            'dAogIC9TdWJ0eXBlIC9UeXBlMQogIC9CYXNlRm9udCAvVGltZXMtUm9tYW4KPj4KZW5kb2Jq' +
            'Cgo1IDAgb2JqICAlIHBhZ2UgY29udGVudAo8PAogIC9MZW5ndGggNDQKPj4Kc3RyZWFtCkJU' +
            'CjcwIDUwIFRECi9GMSAxMiBUZgooSGVsbG8sIHdvcmxkISkgVGoKRVQKZW5kc3RyZWFtCmVu' +
            'ZG9iagoKeHJlZgowIDYKMDAwMDAwMDAwMCA2NTUzNSBmIAowMDAwMDAwMDEwIDAwMDAwIG4g' +
            'CjAwMDAwMDAwNzkgMDAwMDAgbiAKMDAwMDAwMDE3MyAwMDAwMCBuIAowMDAwMDAwMzAxIDAw' +
            'MDAwIG4gCjAwMDAwMDAzODAgMDAwMDAgbiAKdHJhaWxlcgo8PAogIC9TaXplIDYKICAvUm9v' +
            'dCAxIDAgUgo+PgpzdGFydHhyZWYKNDkyCiUlRU9G';
          window.open("data:application/pdf;base64," + pdfData);
    }
    document.getElementById("base64Pdf").onclick = openPDF;


});